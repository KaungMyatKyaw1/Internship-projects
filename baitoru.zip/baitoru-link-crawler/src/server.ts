
import * as dotenv from "dotenv";
dotenv.config();

import express from "express";
import { pageCrawler } from "./pageCrawler";
const app = express();

export const PROJECT_ID = process.env.PROJECT_ID;
export const DATASET_ID = process.env.DATASET_ID;
export const TOTAL_COUNT_TABLE = process.env.TOTAL_COUNT_TABLE;
export const REGION = process.env.REGION;
export const JOB_QUEUE = process.env.JOB_QUEUE;
export const JOB_CRAWLER_SERVICE = process.env.JOB_CRAWLER_SERVICE;
export const TASK_SERVICE_ACC = process.env.TASK_SERVICE_ACC;

app.get("/", async (req, res) => {
    // Declare Environment Variables
    const URL = process.env.URL;

    const requiredEnvVariables = [
        URL,
        PROJECT_ID,
        DATASET_ID,
        TOTAL_COUNT_TABLE,
        REGION,
        TASK_SERVICE_ACC,
        JOB_QUEUE,
        JOB_CRAWLER_SERVICE
    ];
    if (
        requiredEnvVariables.filter(function (value) {
            if (value === undefined) return value;
        }).length > 0
    ) {
        throw Error("必須の「環境変数」は提供されていません。");
    }

    // call main function
    await pageCrawler({ url: URL });
    res.end();
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
    console.log("ポート", port, "でリッスンしている");
    console.log("クローラーシステムを起動している");
    console.log(process.env.URL);
});
