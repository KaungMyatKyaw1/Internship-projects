import { BigQuery } from "@google-cloud/bigquery";

import { TOTAL_COUNT_TABLE_SCHEMA } from "../../schemas/totalCountSchema";

export interface Dataset {
    datasetId: string;
    tableId: string;
}

const bigqueryClient = new BigQuery();

export const checkTable = async ({ datasetId, tableId }: Dataset): Promise<boolean> => {
    const result = await bigqueryClient.dataset(datasetId).table(tableId).exists();
    return result[0];
};

export const createTable = async ({ datasetId, tableId }: Dataset) => {
    const [table] = await bigqueryClient
                .dataset(datasetId)
                .createTable(tableId, TOTAL_COUNT_TABLE_SCHEMA);
    console.log(`Table ${table.id} created.`);
};

export const prepareTable = async ({ datasetId, tableId }: Dataset) => {
    const existsTable = await checkTable({ datasetId, tableId });

    if (existsTable) {
        return;
    }

    try {
        await createTable({ datasetId, tableId });
    } catch (error) {
        console.log("Error while creating 'total' table in Bigquery " + error);
    }
};