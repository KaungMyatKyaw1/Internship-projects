// Imports the Google Cloud Tasks library.
import { CloudTasksClient } from "@google-cloud/tasks";
import moment from "moment-timezone";
import {
	REGION,
	PROJECT_ID,
	JOB_QUEUE,
	JOB_CRAWLER_SERVICE,
	TASK_SERVICE_ACC,
} from "../server";

// Instantiates a client.
const client = new CloudTasksClient();

export const taskForJobs = async ({
	url
}: {
	url: string
}) => {
	// Construct the fully qualified queue name.
	const inSeconds = 1;
	const parent = client.queuePath(
		PROJECT_ID,
		REGION,
		JOB_QUEUE
	);

	const todayDate = moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD");

	const task: any = {
		httpRequest: {
			httpMethod: "GET",
			url: `${JOB_CRAWLER_SERVICE}/?url=https://www.baitoru.com${url}&date=${todayDate}`,
			oidcToken: {
				serviceAccountEmail: TASK_SERVICE_ACC
			}
		},
		scheduleTime: {
			seconds: inSeconds,
		}
	};

	if (inSeconds) {
		// The time when the task is scheduled to be attempted.
		task.scheduleTime = {
			seconds: inSeconds + Date.now() / 1000,
		};
	}

	// Send create task request.
	// console.log(`「${url}」送信タスクが実行されている。。。`);
	const request = { parent, task };
	const [response] = await client.createTask(request);
	// console.log(`「${response.name}　タスク」を作成した。`);
};