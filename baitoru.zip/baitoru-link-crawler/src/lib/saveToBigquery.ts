import { BigQuery, BigQueryDate } from "@google-cloud/bigquery";

const bigqueryClient = new BigQuery();

export interface TotalCountArgs {
    count: number;
    crawlerName: string;
    insertedDate: BigQueryDate;
    totalPages: number;
    jobsPerPage: number;
}

export const saveToBigquery = async ({
    datasetId,
    tableId,
    row
}: {
    datasetId: string;
    tableId: string;
    row: TotalCountArgs;
}) => {
    const rows = [row];
    await bigqueryClient.dataset(datasetId).table(tableId).insert(rows);
    console.log(`「Dataset → ${datasetId}」,「Table → ${tableId}」に挿入しました。`);
};