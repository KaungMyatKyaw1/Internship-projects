import { BigQuery } from "@google-cloud/bigquery";
import got from "got";
import { JSDOM } from "jsdom";
import moment from "moment-timezone";
import { prepareTable } from "./lib/bigqueryPreparation";
import { saveToBigquery } from "./lib/saveToBigquery";
import { taskForJobs } from "./lib/taskCreator";
import { DATASET_ID, TOTAL_COUNT_TABLE } from "./server";

export const pageCrawler = async ({
    url
}: {
    url: string;
}) => {
    const bigqueryPartitionDate = moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYYMMDD");
    const totalCountTableId = TOTAL_COUNT_TABLE + "_" + bigqueryPartitionDate;
    const datasetId = DATASET_ID;

    const firstListResponse = await got(url);
    const firstListDom = new JSDOM(firstListResponse.body);

    const lastPageNumber = parseInt(firstListDom.window.document.querySelector(".common-globalPager .pattern-1 .pt01 ol .last").textContent.replace(/,/g, ""), 10);
    console.log(`Last Page Number: ${lastPageNumber}`);

    console.log(`First Page URL: ${url}`);
    const { links, helloworkLinks } = await createGotLinksToTasks({ dom: firstListDom, pageNumber: 1 });

    const jobsPerPage: number = links.length + helloworkLinks.length;
    let jobsCount: number = 0;
    let totalPages: number;
    const pendingTasks = [];
    for (const link of links) {
        pendingTasks.push(taskForJobs({ url: link }));
    }
    await Promise.all(pendingTasks);

    for (let i = 0; i < lastPageNumber; i++) {
        const pageNumber = i+2;
        const jobUrl = `${url}page${pageNumber}/`;
        console.log(`「URL: ${jobUrl}」のリンクをタスクに作成します。`);
        const eachPageResponse = await got(jobUrl);
        const listDom = new JSDOM(eachPageResponse.body);

        const { links, helloworkLinks } = await createGotLinksToTasks({ dom: listDom, pageNumber });

        jobsCount += links.length;
        for (const [index, link] of links.entries()) {
            totalPages = (helloworkLinks.length > 0) ? index + 1 : null;
            pendingTasks.push(taskForJobs({ url: link }));
        }
        await Promise.all(pendingTasks);

        if (helloworkLinks.length > 0) {
            break;
        }
    }

    console.log(`Jobs Count: ${jobsCount}`);
    await prepareTable({ datasetId, tableId: totalCountTableId });
    await saveToBigquery({
        datasetId,
        tableId: totalCountTableId,
        row: {
            count: jobsCount,
            crawlerName: "baitoru",
            insertedDate: BigQuery.date(moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DD")),
            totalPages,
            jobsPerPage,
        }
    });
}

const createGotLinksToTasks = async ({
    dom,
    pageNumber,
}: {
    dom: JSDOM;
    pageNumber: number;
}) => {
    const links = Array.from(dom.window.document.querySelectorAll(".list-jobListDetail .pattern-1 .ul01 .li01 h3 a"))
        .map((e: HTMLAnchorElement) => e.href);
    const helloworkLinks = Array.from(dom.window.document.querySelectorAll<HTMLElement>(".list-jobListDetailH"));
    console.log(`「ページ番号 -  ${pageNumber}」 にハローワーク リンクが見つかった件数： ${helloworkLinks.length}`);

    return { links, helloworkLinks };
}