export const JOB_TABLE_SCHEMA: any = {
    sourceFormat: "NEWLINE_DELIMITED_JSON",
    schema: {
        fields: [
            { name: "jobId", type: "INTEGER" },
            { name: "catchText", type: "STRING" },
            { name: "welcomeMessageSummary", type: "STRING" },
            { name: "occupation", type: "STRING" },
            {
                name: "salaryTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "salaryDescription", type: "STRING" },
            {
                name: "workingHoursTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "workingHoursDescription", type: "STRING" },
            {
                name: "workPlaceTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "workPlaceDescription", type: "STRING" },
            { name: "interviewLocationSummary", type: "STRING" },
            {
                name: "featuresTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "earningsTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "qualificationsTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "workEnvironmentTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "treatmentTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "appearenceTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            {
                name: "benefitsTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "welcomeMessageDescription", type: "STRING" },
            {
                name: "applicationRemark",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "title", type: "STRING" },
                    { name: "content", type: "STRING" },
                ]
            },
            { name: "jobDescription", type: "STRING" },
            { name: "workingPeriod", type: "STRING" },
            {
                name: "holidaysTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "holidaysDescription", type: "STRING" },
            {
                name: "experienceAndQualificationTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "experienceAndQualificationDescription", type: "STRING" },
            {
                name: "treatmentAndWelfareTags",
                type: "RECORD",
                mode: "REPEATED",
                fields: [
                    { name: "tagContent", type: "STRING" },
                ]
            },
            { name: "treatmentAndWelfareDescription", type: "STRING" },
            { name: "recruitmentPlaceName", type: "STRING" },
            { name: "interviewLocationDescription", type: "STRING" },
            { name: "applicationMethod", type: "STRING" },
            { name: "recruiterName", type: "STRING" },
            { name: "companyLogo", type: "STRING" },
            { name: "companyName", type: "STRING" },
            { name: "companyAddress", type: "STRING" },
            { name: "contactPhone", type: "STRING" },
            { name: "representativeName", type: "STRING" },
            { name: "dispatchPermissionNumber", type: "STRING" },
            { name: "businessLicenseNumber", type: "STRING" },
            { name: "serviceArea", type: "STRING" },
            { name: "branchLocationList", type: "STRING" },
            { name: "applicationProcess", type: "STRING" },
            { name: "businessDescription", type: "STRING" },
            { name: "homePage", type: "STRING" },
            { name: "publicationStartDate", type: "DATE" },
            { name: "expectedEndDate", type: "DATE" },
            { name: "createdAt", type: "DATETIME" },
        ],
    },
    location: "asia-northeast1",
};