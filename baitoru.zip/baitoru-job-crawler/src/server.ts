import * as dotenv from "dotenv";
dotenv.config();

import express from "express";
import moment from "moment-timezone";
import got from "got";
import { JSDOM } from "jsdom";

import { crawlJobData, getDataByClass, getJobId } from "./lib/crawlJobData";
import { prepareTable } from "./lib/bigqueryPreparation";
import { saveToBigquery } from "./lib/saveToBigquery";
import { Job } from "./lib/dataDefinition";
import { BigQuery } from "@google-cloud/bigquery";
const app = express();

app.get("/", async (req, res) => {
  const jobUrl = req.query.url.toString();

  const DATASET_ID = process.env.DATASET_ID;
  const TABLE_ID = process.env.TABLE_ID;

  const queryDate = req.query.date as string;
  if(!queryDate) {
    res.status(400).json({
      message: "date is not provided"
    })
  }
  const date = new Date(queryDate)
  const yearMonthDay = moment(date).format("YYYYMMDD")

  const STATUS_TABLE_ID = TABLE_ID + "_status_" + yearMonthDay;
  const JOBS_TABLE_ID = TABLE_ID + "_jobs_" + yearMonthDay;

  await Promise.all([
    prepareTable({
      datasetId: DATASET_ID,
      tableId: STATUS_TABLE_ID,
      tableType: "status",
    }),
    prepareTable({
      datasetId: DATASET_ID,
      tableId: JOBS_TABLE_ID,
      tableType: "jobs",
    }),
  ]);

  const jobId = getJobId({ url: jobUrl });
  console.log(`JobId: ${jobId}`);
  let companyName;
  try {
    const responseData = await got(jobUrl);
    // console.log(`Response Status: ${responseData.statusMessage}`);
    const body = responseData.body;
    // console.log(`Body: ${body}`);
    const start = `<div class="layout-column-1">`;
    const end = `<div class="layout-column-2">`;
    const requiredHTML =
      body.substring(body.indexOf(start), body.indexOf(end) + end.length) +
      "</div>";
    // console.log(`Required HTML: ${requiredHTML}`);
    const dom = new JSDOM(requiredHTML);
    companyName = getDataByClass({
      dom,
      className: ".detail-companyInfo .bg01 > .pt02 > dl > dd > p",
    });
    console.log("this is the company name" + companyName);
    
    // 詳細情報を取る
    const jobInfo: Job = await crawlJobData({ dom, jobId });
    console.log(`Job Info: ${JSON.stringify(jobInfo)}`);
    
    // await Promise.all([
    await saveToBigquery({
      datasetId: DATASET_ID,
      tableId: JOBS_TABLE_ID,
      row: jobInfo,
    });
    await saveToBigquery({
      datasetId: DATASET_ID,
      tableId: STATUS_TABLE_ID,
      row: {
        jobId,
        companyName,
        pageNo: "-",
        url: jobUrl,
        crawlStatus: "成功",
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
  } catch (error) {
    console.log(
      `クロールするかbigqueryに入れるうちにエラーがある：　${JSON.stringify(
        error
      )}`
    );
    await saveToBigquery({
      datasetId: DATASET_ID,
      tableId: STATUS_TABLE_ID,
      row: {
        jobId,
        companyName,
        pageNo: "-",
        url: jobUrl,
        crawlStatus: "失敗",
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
  }

  res.end();
});

const port = 8081;
app.listen(port, () => {
  console.log("ポート", port, "でリッスンしている");
  console.log("クローラーシステムを起動している");
});
