import { BigQuery } from "@google-cloud/bigquery";

import { JOB_TABLE_SCHEMA } from "../../schemas/jobSchema";
import { STATUS_TABLE_SCHEMA } from "../../schemas/statusSchema";
import { Dataset, PrepareArgs } from "./dataDefinition";

const bigqueryClient = new BigQuery();

export const checkTable = async ({ datasetId, tableId }: Dataset): Promise<boolean> => {
    const result = await bigqueryClient.dataset(datasetId).table(tableId).exists();
    return result[0];
};

export const createTable = async ({ datasetId, tableId, tableType }: PrepareArgs) => {
    let table;
    switch (tableType) {
        case "jobs":
            [table] = await bigqueryClient
                .dataset(datasetId)
                .createTable(tableId, JOB_TABLE_SCHEMA);
            break;
        case "status":
            [table] = await bigqueryClient
                .dataset(datasetId)
                .createTable(tableId, STATUS_TABLE_SCHEMA);
            break;
        default:
            break;
    }
    console.log(`Table ${table.id} created.`);
};

export const prepareTable = async ({ datasetId, tableId, tableType }: PrepareArgs) => {
    const existsTable = await checkTable({ datasetId, tableId });

    if (existsTable) {
        return;
    }

    try {
        await createTable({ datasetId, tableId, tableType });
    } catch (error) {
        console.log("Error while creating 'total' table in Bigquery " + error);
    }
};