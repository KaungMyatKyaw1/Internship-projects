import { BigQuery } from "@google-cloud/bigquery";
import { InsertArgs } from "./dataDefinition";

const bigqueryClient = new BigQuery();

export const saveToBigquery = async ({ datasetId, tableId, row }: InsertArgs) => {
  const rows = [row];
  await bigqueryClient.dataset(datasetId).table(tableId).insert(rows);
  console.log(`「Dataset → ${datasetId}」,「Table → ${tableId}」に挿入しました。`);
};