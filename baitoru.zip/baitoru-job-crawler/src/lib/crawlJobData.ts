import { BigQuery } from "@google-cloud/bigquery";
import { JSDOM } from "jsdom";
import moment from "moment";

export const crawlJobData = async ({
    dom,
    jobId,
}: {
    dom: JSDOM;
    jobId: number;
}) => {
    const contactData = (getTableDataByOneSelector({
        dom,
        selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
        title: "所在地"
    })).split("\t\t\t\t\t");

    return {
        jobId,
        catchText: getDataByClass({
            dom,
            className: ".detail-detailHeader h2"
        }),
        welcomeMessageSummary: getDataByClass({
            dom,
            className: ".detail-detailHeader .pt02 p"
        }),
        occupation: getTableDataByOneSelector({
            dom,
            selector: ".detail-basicInfo .bg01 > dl > dt",
            title: "職種"
        }),
        salaryTags: getTagsFromTable({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: ".ul01 span",
            title: "給与"
        }),
        salaryDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: "ul:nth-child(2), div",
            title: "給与"
        }),
        workingHoursTags: getTagsFromTable({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: ".ul01 span",
            title: "勤務時間"
        }),
        workingHoursDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: ".ul02, .ul03",
            title: "勤務時間"
        }),
        workPlaceTags: getTagsFromTable({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: ".ul01 span",
            title: "勤務地・面接地"
        }) || getTagsFromTable({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: ".ul01 span",
            title: "勤務地"
        }),
        workPlaceDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: "dl",
            title: "勤務地・面接地"
        }) || getTableDataByTwoSelector({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: "dl",
            title: "勤務地"
        }),
        interviewLocationSummary: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-basicInfo .bg01 > dl > dt",
            selector2: "dl",
            title: "面接地"
        }),
        featuresTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "人気の特徴"
        }),
        earningsTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "稼ぎ方"
        }),
        qualificationsTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "～な方を歓迎"
        }),
        workEnvironmentTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "職場環境"
        }),
        treatmentTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "魅力的な待遇"
        }),
        appearenceTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "自分らしい恰好"
        }),
        benefitsTags: getTagsFromTable({
            dom,
            selector1: ".detail-companyChar .js-da-target dl dt",
            selector2: "ul li",
            title: "応募時のメリット"
        }),
        welcomeMessageDescription: getDataByClass({
            dom,
            className: ".detail-companyEnvironment p"
        }),
        applicationRemark: [getApplicationRemark({ dom })],
        jobDescription: getTableDataByOneSelector({
            dom,
            selector: ".detail-recruitInfo .bg01 > dl > dt",
            title: "仕事内容"
        }),
        workingPeriod: getTableDataByOneSelector({
            dom,
            selector: ".detail-recruitInfo .bg01 > dl > dt",
            title: "勤務期間"
        }),
        holidaysTags: getTagsFromTable({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: ".ul01 li",
            title: "休日・休暇"
        }),
        holidaysDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: "p",
            title: "休日・休暇"
        }),
        experienceAndQualificationTags: getTagsFromTable({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: ".ul01 li",
            title: "経験・資格"
        }),
        experienceAndQualificationDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: "p",
            title: "経験・資格"
        }),
        treatmentAndWelfareTags: getTagsFromTable({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: ".ul01 li",
            title: "待遇・福利厚生"
        }),
        treatmentAndWelfareDescription: getTableDataByTwoSelector({
            dom,
            selector1: ".detail-recruitInfo .bg01 > dl > dt",
            selector2: "p",
            title: "待遇・福利厚生"
        }),
        recruitmentPlaceName: getTableDataByOneSelector({
            dom,
            selector: ".detail-entryInfo .bg01 > dl > dt",
            title: "応募先"
        }),
        interviewLocationDescription: getTableDataByOneSelector({
            dom,
            selector: ".detail-entryInfo .bg01 > dl > dt",
            title: "面接地"
        }),
        applicationMethod: getTableDataByOneSelector({
            dom,
            selector: ".detail-entryInfo .bg01 > dl > dt",
            title: "応募方法"
        }),
        recruiterName: getTableDataByOneSelector({
            dom,
            selector: ".detail-entryInfo .bg01 > dl > dt",
            title: "担当者"
        }),
        companyLogo: getImage({ dom }),
        companyName: getDataByClass({
            dom,
            className: ".detail-companyInfo .bg01 > .pt02 > dl > dd > p"
        }),
        companyAddress: contactData[0],
        contactPhone: (contactData.length > 1) ? contactData[1] : null,
        representativeName: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "所在地"
        }),
        dispatchPermissionNumber: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "派遣許可番号"
        }),
        businessLicenseNumber: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "有料職業紹介事業許可番号"
        }),
        serviceArea: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "サービス地域"
        }),
        branchLocationList: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "拠点"
        }),
        applicationProcess: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "応募プロセス"
        }),
        businessDescription: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "事業内容"
        }),
        homePage: getTableDataByOneSelector({
            dom,
            selector: ".detail-companyInfo .bg01 > .pt03 > dl > dt",
            title: "URL"
        }),
        publicationStartDate: getDate({
            dom,
            title: "掲載開始日"
        }),
        expectedEndDate: getDate({
            dom,
            title: "掲載終了予定日"
        }),
        createdAt: BigQuery.datetime(moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss"))
    }
}

export const getJobId = ({
    url
}: {
    url: string
}) => {
    const urlParts = url.split("/");
    const rawJobId = urlParts[urlParts.length - 2]; // e.g. job80377925
    const jobId = rawJobId.slice(3);
    return parseInt(jobId, 10);
}

export const getDataByClass = ({
    dom,
    className
}: {
    dom: JSDOM;
    className: string;
}) => {
    const crawledElement = dom.window.document.querySelector<HTMLElement>(className);
    const crawledText = crawledElement ? crawledElement.textContent.trim() : null;
    return crawledText;
}

const getTableDataByOneSelector = ({
    dom,
    selector,
    title
}: {
    dom: JSDOM;
    selector: string;
    title: string;
}) => {
    const crawledTitleElement = Array.from(dom.window.document.querySelectorAll(selector))
        .find((e: HTMLElement) => e.textContent === title);
    const nextSiblingElement = crawledTitleElement ? crawledTitleElement.nextElementSibling : null;
    const contentOfNextElement = nextSiblingElement ? nextSiblingElement.textContent.trim() : null;
    return contentOfNextElement;
}

const getTableDataByTwoSelector = ({
    dom,
    selector1,
    selector2,
    title
}: {
    dom: JSDOM;
    selector1: string;
    selector2: string;
    title: string;
}) => {
    const crawledTitleElement = Array.from(dom.window.document.querySelectorAll(selector1))
        .find((e: HTMLElement) => e.textContent === title);
    const nextSiblingElement = crawledTitleElement ? crawledTitleElement.nextElementSibling : null;
    const childElementOfNextElement = nextSiblingElement ? nextSiblingElement.querySelectorAll(selector2) : null;
    const childContentOfNextElement = childElementOfNextElement
        ? Array.from(childElementOfNextElement).map((e) => e.textContent.trim()).join("\n")
        : null;
    return childContentOfNextElement;
}

const getTagsFromTable = ({
    dom,
    selector1,
    selector2,
    title
}: {
    dom: JSDOM;
    selector1: string;
    selector2: string;
    title: string;
}) => {
    const crawledTitleElement = Array.from(dom.window.document.querySelectorAll(selector1))
        .find((e: HTMLElement) => e.textContent === title);
    const nextSiblingElement = crawledTitleElement ? crawledTitleElement.nextElementSibling : null;
    const childElementOfNextElement = nextSiblingElement ? nextSiblingElement.querySelectorAll(selector2) : null;
    const childTagContentOfNextElement = childElementOfNextElement
        ? Array.from(childElementOfNextElement).map((e) => {
            return {
                tagContent: e.textContent.trim()
            }
        })
        : [{ tagContent: null }];
    return childTagContentOfNextElement;
}

const getApplicationRemark = ({
    dom
}: {
    dom: JSDOM
}) => {
    const titleElement = dom.window.document.querySelector(".detail-recruitInfo .bg01 > dl");
    const contentElement = dom.window.document.querySelector(".detail-recruitInfo .bg01 > dd");
    return {
        title: titleElement ? titleElement.textContent.trim() : null,
        content: contentElement ? contentElement.textContent.trim() : null,
    }
}

const getDate = ({
    dom,
    title
}: {
    dom: JSDOM,
    title: string
}) => {
    const dateElements = Array.from(
        dom.window.document.querySelectorAll("._jobOfferDate li")
    ).filter(e => e.textContent.trim().includes(title));
    const dateIncludedText = dateElements[0].textContent.trim();
    const date = dateIncludedText ? BigQuery.date(moment(dateIncludedText.slice(title.length + 1)).format("YYYY-MM-DD")) : null;
    return date;
}

const getImage = ({
    dom
}: {
    dom: JSDOM
}) => {
    const crawledElement = dom.window.document.querySelector<HTMLImageElement>(".detail-companyInfo .bg01 > .pt02 > dl > dt > a > img");
    const crawledImageSrc = crawledElement ? `https://www.baitoru.com${crawledElement.src}` : null;
    return crawledImageSrc;
}