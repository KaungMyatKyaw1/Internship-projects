import { BigQueryDate, BigQueryDatetime, BigQueryTime } from "@google-cloud/bigquery";

export interface Dataset {
    datasetId: string;
    tableId: string;
}

export interface InsertArgs extends Dataset {
    row: Status | Job;
}

export interface PrepareArgs extends Dataset {
    tableType: string;
}

export interface Status {
    jobId: number;
    companyName: string;
    pageNo: string;
    url: string;
    crawlStatus: string;
    createdAt: BigQueryDatetime;
}

interface TagsRecord {
    tagContent: string;
}

interface ApplicationRemarkRecord {
    title: string;
    content: string;
}

export interface Job {
    jobId: number;
    catchText: string;
    welcomeMessageSummary: string;
    occupation: string;
    salaryTags: TagsRecord[];
    salaryDescription: string;
    workingHoursTags: TagsRecord[];
    workingHoursDescription: string;
    workPlaceTags: TagsRecord[];
    workPlaceDescription: string;
    interviewLocationSummary: string;
    featuresTags: TagsRecord[];
    earningsTags: TagsRecord[];
    qualificationsTags: TagsRecord[];
    workEnvironmentTags: TagsRecord[];
    treatmentTags: TagsRecord[];
    appearenceTags: TagsRecord[];
    benefitsTags: TagsRecord[];
    welcomeMessageDescription: string;
    applicationRemark: ApplicationRemarkRecord[];
    jobDescription: string;
    workingPeriod: string;
    holidaysTags: TagsRecord[];
    holidaysDescription: string;
    experienceAndQualificationTags: TagsRecord[];
    experienceAndQualificationDescription: string;
    treatmentAndWelfareTags: TagsRecord[];
    treatmentAndWelfareDescription: string;
    recruitmentPlaceName: string;
    interviewLocationDescription: string;
    applicationMethod: string;
    recruiterName: string;
    companyLogo: string;
    companyName: string;
    companyAddress: string;
    contactPhone:string;
    representativeName: string;
    dispatchPermissionNumber: string;
    businessLicenseNumber:  string;
    serviceArea: string;
    branchLocationList: string;
    applicationProcess: string;
    businessDescription: string;
    homePage: string;
    publicationStartDate: BigQueryDate;
    expectedEndDate: BigQueryDate;
    createdAt: BigQueryDatetime;
}