import * as dotenv from "dotenv";
dotenv.config();

import { Page } from "puppeteer";
import { Job } from "./data-definition";
import { extractJob } from "./lib/extractJob";

import { insertStatus } from "./lib/saveToDBFunctions";
import { insertJob } from "./lib/saveToDBFunctions";
import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment-timezone";

interface Args {
  page: Page;
  url: string;
  yearMonthDay: string;
}

export const sleep = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));

export const crawl = async ({ page, url, yearMonthDay }: Args) => {
  // const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");
  const statusTableId = process.env.STATUS_TABLE_ID + "_" + yearMonthDay;
  const jobTableId = process.env.JOB_TABLE_ID + "_" + yearMonthDay;
  const datasetId = process.env.DATASET_ID;

  // jobId
  const jobId = url
    .split("/")
    .filter((urlPart) => urlPart.includes("RQ"))[0]
    .split("_")[1];

  const jobInfo: boolean | string | Job = await extractJob({
    page,
    url,
    jobId,
  });
  if (!jobInfo) {
    console.log("失敗");
    await insertStatus({
      datasetId,
      tableId: statusTableId,
      row: {
        jobId,
        companyName: "",
        url,
        crawlStatus: "失敗",
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
    return;
  }
  if (jobInfo === "失敗" || jobInfo === "掲載終了") {
    console.log(jobInfo);
    await insertStatus({
      datasetId,
      tableId: statusTableId,
      row: {
        jobId,
        companyName: "",
        url,
        crawlStatus: jobInfo.toString(),
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
    return;
  }

  try {
    console.log(`Bigquery に保存している。。。`);
    await insertJob({
      datasetId,
      tableId: jobTableId,
      row: { ...(jobInfo as Job) },
    });
    await insertStatus({
      datasetId,
      tableId: statusTableId,
      row: {
        jobId,
        companyName: (jobInfo as Job).companyName,
        url,
        crawlStatus: "成功",
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
    return;
  } catch (error) {
    console.log(`保存するうちにエラーがある、JobId -> ${jobId}, URL -> ${url}`);
    await insertStatus({
      datasetId,
      tableId: statusTableId,
      row: {
        jobId,
        companyName: (jobInfo as Job).companyName,
        url,
        crawlStatus: "失敗",
        createdAt: BigQuery.datetime(
          moment
            .tz(moment(new Date()), "Asia/Tokyo")
            .format("YYYY-MM-DDTHH:mm:ss")
        ),
      },
    });
    return;
  }
};
