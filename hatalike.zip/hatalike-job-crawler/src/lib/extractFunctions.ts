import { Page } from "puppeteer";

interface TableExtractArgs {
  page: Page;
  thText: string;
}
interface ExcludeArgs {
  page: Page;
  excludes: string[];
}
interface CompanyInfoArgs {
  page: Page;
  dtText: string;
}

export const getDataFromTable = async ({ page, thText }: TableExtractArgs) => {
  return page.evaluate(
    function ({ thText }: { thText: string }) {
      const trs = Array.from(document.querySelectorAll(".design01 tr"));
      const row = trs.filter((tr) => {
        const th = tr.querySelector("th");
        if (!th) return false;
        return tr.querySelector("th").textContent.trim().includes(thText);
      })[0];
      if (!row) {
        return "";
      }

      const tdEle = row.querySelector("td");
      return tdEle ? tdEle.textContent.trim() : "";
    },
    {
      thText,
    }
  );
};
export const getJobRemarksFromTable = async ({
  page,
  excludes,
}: ExcludeArgs) => {
  return page.evaluate(
    function ({ excludes }: { excludes: string[] }) {
      const trs = Array.from(document.querySelectorAll(".design01 tr"));
      const rows = trs.filter((tr) => {
        const th = tr.querySelector("th");
        if (!th) return false;
        return !excludes.includes(tr.querySelector("th").textContent.trim());
      });
      if (!rows.length) {
        return [];
      }

      return rows.map((row) => {
        return {
          title: row.querySelector("th")
            ? row.querySelector("th").textContent.trim()
            : "",
          body: row.querySelector("td")
            ? row.querySelector("td").textContent.trim()
            : "",
        };
      });
    },
    {
      excludes,
    }
  );
};

export const getCompanyInfo = async ({ page, dtText }: CompanyInfoArgs) => {
  return page.evaluate(
    function ({ dtText }: { dtText: string }) {
      const dt = Array.from(
        document.querySelectorAll(".companyInfo dt")
      ).filter((dt) => dt.textContent.trim().includes(dtText))[0];
      if (!dt) return "";
      const dd = dt.nextElementSibling;
      return dd ? dd.textContent.trim() : "";
    },
    {
      dtText,
    }
  );
};

export const getCompanyRemarks = async ({ page, excludes }: ExcludeArgs) => {
  return page.evaluate(
    function ({ excludes }: { excludes: string[] }) {
      const dts = Array.from(
        document.querySelectorAll(".companyInfo dt")
      ).filter((dt) => !excludes.includes(dt.textContent.trim()));

      return dts.map((dt) => {
        return {
          title: dt ? dt.textContent.trim() : "",
          body: dt.nextElementSibling
            ? dt.nextElementSibling.textContent.trim()
            : "",
        };
      });
    },
    {
      excludes,
    }
  );
};
