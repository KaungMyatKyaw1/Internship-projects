import { Page } from "puppeteer";
import {
  getDataFromTable,
  getJobRemarksFromTable,
  getCompanyInfo,
  getCompanyRemarks,
} from "./extractFunctions";
import { sleep } from "../crawl";
import { Job } from "../data-definition";
import moment from "moment-timezone";
import { BigQuery } from "@google-cloud/bigquery";

interface ExtractArgs {
  page: Page;
  url: string;
  jobId: string;
}
interface GoToPageArgs {
  page: Page;
  url: string;
}

export const gotoPage = async ({ page, url }: GoToPageArgs) => {
  try {
    console.log(`Going to ${url}`);
    await page.goto(url);
    return true;
  } catch (error) {
    console.log(error);
    return false;
  }
};

export const extractJob = async ({
  page,
  url,
  jobId,
}: ExtractArgs): Promise<boolean | string | Job> => {
  // jobTitle
  // const jobTitleEle = document.querySelector(".jsc_float_trigger_st .em01");
  // const jobTitle = jobTitleEle ? jobTitleEle.textContent.trim() : "";

  const jobInfoFields = [
    "職種/仕事内容",
    "対象となる方",
    "勤務地",
    "アクセス",
    "勤務時間",
    "給与",
    "休日休暇",
    "待遇・福利厚生",
    "採用予定人数",
    "応募方法",
    "選考プロセス",
    "連絡先/担当者",
  ];

  const companyInfoFields = [
    "会社名",
    "設立",
    "代表者",
    "資本金",
    "従業員数",
    "所在住所",
    "売上高",
    "事業内容",
    "ホームページ",
  ];

  const reachPage = await gotoPage({
    page,
    url,
  });

  if (reachPage) {
    const crawlStatus = await page.evaluate(() => {
      const postingEndVal = document.querySelector(".systemError");
      const headLeftEle = document.querySelector(".headLeft");
      if (postingEndVal) {
        return "掲載終了";
      }
      if (headLeftEle) {
        return "失敗";
      }
      return "成功";
    });
    if (!(crawlStatus === "成功")) {
      return crawlStatus;
    }

    // jobTitle
    const jobTitle = await page.evaluate(() => {
      const jobTitleEle = document.querySelector(".jsc_float_trigger_st .em01");
      return jobTitleEle ? jobTitleEle.textContent.trim() : "";
    });

    const { publicationStartDateStr, publicationEndDateStr } =
      await page.evaluate(() => {
        const periodEle = document.querySelector(".period .em01");

        const [date, time] = periodEle
          ? periodEle.textContent.trim().split(/(\s+)/)
          : [];
        const [publicationStartDateStr, publicationEndDateStr] = date
          ? date.split("～").map((date) => (date ? date.replace("/", "-") : ""))
          : [];

        return {
          publicationStartDateStr,
          publicationEndDateStr,
        };
      });

    // publicationStartDate
    // publicatinoEndDate

    const publicationStartDate = publicationStartDateStr
      ? BigQuery.date(
          moment
            .tz(moment(new Date(publicationStartDateStr)), "Asia/Tokyo")
            .format("YYYY-MM-DD")
        )
      : null;
    const publicationEndDate = publicationEndDateStr
      ? BigQuery.date(
          moment
            .tz(moment(new Date(publicationEndDateStr)), "Asia/Tokyo")
            .format("YYYY-MM-DD")
        )
      : null;

    // jobCatchTitle
    const jobCatchTitle = await page.evaluate(() => {
      const jobCatchTitleEle = document.querySelector(".lead");
      return jobCatchTitleEle ? jobCatchTitleEle.textContent.trim() : "";
    });

    // jobCatchText
    const jobCatchText = await page.evaluate(() => {
      const jobCatchTextEle = document.querySelector(".detailTxt");
      return jobCatchTextEle ? jobCatchTextEle.textContent.trim() : "";
    });

    // jobCatchImg
    const jobCatchImg = await page.evaluate(() => {
      const imgEle: HTMLImageElement = document.querySelector(
        ".detailCol .layout_table .photo img"
      );
      return imgEle ? imgEle.src : "";
    });

    // jobFeatures
    const jobFeatures = await page.evaluate(() => {
      const featureTables = Array.from(
        document.querySelectorAll(".like_topic_list > .layout_table")
      );
      return featureTables.map((table) => {
        return {
          title: table.querySelector("dt")
            ? table.querySelector("dt").textContent.trim()
            : "",
          body: table.querySelector("dd")
            ? table.querySelector("dd").textContent.trim()
            : "",
        };
      });
    });

    // jobDescription
    const jobDescription = await getDataFromTable({
      page,
      thText: "職種/仕事内容",
    });

    // eligiblePerson
    const eligiblePerson = await getDataFromTable({
      page,
      thText: "対象となる方",
    });

    // workLocation
    const workLocation = await getDataFromTable({
      page,
      thText: "勤務地",
    });

    // access
    const access = await getDataFromTable({
      page,
      thText: "アクセス",
    });

    // workingHours
    const workingHours = await getDataFromTable({
      page,
      thText: "勤務時間",
    });

    // salary
    const salary = await getDataFromTable({
      page,
      thText: "給与",
    });

    // holidays
    const holidays = await getDataFromTable({
      page,
      thText: "休日休暇",
    });

    // benefits
    const benefits = await getDataFromTable({
      page,
      thText: "待遇・福利厚生",
    });

    // plannedNumberOfHires
    const plannedNumberOfHiresNo = parseInt(
      await getDataFromTable({
        page,
        thText: "採用予定人数",
      }),
      10
    );
    const plannedNumberOfHires = plannedNumberOfHiresNo || null;

    // applicationMethod
    const applicationMethod = await getDataFromTable({
      page,
      thText: "応募方法",
    });

    // selectionProcess
    const selectionProcess = await getDataFromTable({
      page,
      thText: "選考プロセス",
    });

    // contact
    const contact = await getDataFromTable({
      page,
      thText: "連絡先/担当者",
    });

    // jobRemarks
    const jobRemarks = await getJobRemarksFromTable({
      page,
      excludes: [...jobInfoFields],
    });

    // companyName
    const companyName = await getCompanyInfo({
      page,
      dtText: "会社名",
    });

    // established
    const established = await getCompanyInfo({
      page,
      dtText: "設立",
    });

    // representative
    const representative = await getCompanyInfo({
      page,
      dtText: "代表者",
    });
    // capital
    const capital = await getCompanyInfo({
      page,
      dtText: "資本金",
    });
    // numberOfEmployees
    const numberOfEmployees = parseInt(
      await getCompanyInfo({
        page,
        dtText: "従業員数",
      }),
      10
    );
    // address
    const address = await getCompanyInfo({
      page,
      dtText: "所在住所",
    });
    // amountOfSales
    const amountOfSales = await getCompanyInfo({
      page,
      dtText: "売上高",
    });
    // businessContent
    const businessContent = await getCompanyInfo({
      page,
      dtText: "事業内容",
    });
    // homePage
    const homePage = await getCompanyInfo({
      page,
      dtText: "ホームページ",
    });

    // companyRemarks
    const companyRemarks = await getCompanyRemarks({
      page,
      excludes: [...companyInfoFields],
    });

    const job = {
      jobId,
      jobTitle,
      jobCatchTitle,
      jobCatchText,
      jobCatchImg,
      publicationStartDate,
      publicationEndDate,
      jobFeatures,
      jobDescription,
      eligiblePerson,
      workLocation,
      access,
      workingHours,
      salary,
      holidays,
      benefits,
      plannedNumberOfHires,
      applicationMethod,
      selectionProcess,
      contact,
      jobRemarks,
      companyName,
      established,
      representative,
      capital,
      numberOfEmployees,
      address,
      amountOfSales,
      businessContent,
      homePage,
      companyRemarks,
      createdAt: BigQuery.datetime(
        moment
          .tz(moment(new Date()), "Asia/Tokyo")
          .format("YYYY-MM-DDTHH:mm:ss")
      ),
    };

    // console.log(job);
    return job;
  } else {
    return false;
  }
};
