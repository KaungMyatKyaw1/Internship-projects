// data definition
import { Status, Job } from "../data-definition";

// bigquery
import { BigQuery } from "@google-cloud/bigquery";

interface InsertStatus {
  datasetId: string;
  tableId: string;
  row: Status;
}
interface InsertJob {
  datasetId: string;
  tableId: string;
  row: Job;
}

const bigquery = new BigQuery();

export const insertStatus = async ({
  datasetId,
  tableId,
  row,
}: InsertStatus) => {
  const rows = [row];
  try {
    console.log(
      `ステータステーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Job ID　→ ${row.jobId}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    console.log("Error");
    console.log(JSON.stringify(error));
  }
};

export const insertJob = async ({ datasetId, tableId, row }: InsertJob) => {
  const rows = [row];
  try {
    console.log(
      `ジョブテーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Job ID　→ ${row.jobId}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    console.log("Error");
    console.log(JSON.stringify(error));
  }
};
