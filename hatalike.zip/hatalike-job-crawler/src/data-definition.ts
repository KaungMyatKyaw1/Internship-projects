import { BigQueryDate, BigQueryDatetime } from "@google-cloud/bigquery";

export interface JobFeaturesRecord {
  title: string;
  body: string;
}
export interface JobRemarksRecord {
  title: string;
  body: string;
}
export interface CompanyRemarksRecord {
  title: string;
  body: string;
}

export interface Job {
  jobId: string;
  jobTitle: string;
  jobCatchTitle: string;
  jobCatchText: string;
  jobCatchImg: string;
  publicationStartDate: BigQueryDate;
  publicationEndDate: BigQueryDate;
  jobFeatures: JobFeaturesRecord[];
  jobDescription: string;
  eligiblePerson: string;
  workLocation: string;
  access: string;
  workingHours: string;
  salary: string;
  holidays: string;
  benefits: string;
  plannedNumberOfHires: number;
  applicationMethod: string;
  selectionProcess: string;
  contact: string;
  jobRemarks: JobRemarksRecord[];
  companyName: string;
  established: string;
  representative: string;
  capital: string;
  numberOfEmployees: number;
  address: string;
  amountOfSales: string;
  businessContent: string;
  homePage: string;
  companyRemarks: CompanyRemarksRecord[];
  createdAt: BigQueryDatetime;
}

export interface Status {
  jobId: string;
  companyName: string;
  url: string;
  crawlStatus: string;
  createdAt: BigQueryDatetime;
}
