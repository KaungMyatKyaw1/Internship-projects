// const makeRequest = () => {
//     // This is the second configuration option
// const res = await axios({
//     method: 'get',
//     url
// });
// }