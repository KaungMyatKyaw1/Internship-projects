export const JOB_TABLE_SCHEMA: any = {
  sourceFormat: "NEWLINE_DELIMITED_JSON",
  schema: {
    fields: [
      { name: "jobId", type: "STRING" },
      { name: "jobTitle", type: "STRING" },
      { name: "jobCatchTitle", type: "STRING" },
      { name: "jobCatchText", type: "STRING" },
      { name: "jobCatchImg", type: "STRING" },
      { name: "publicationStartDate", type: "DATE" },
      { name: "publicationEndDate", type: "DATE" },
      {
        name: "jobFeatures",
        type: "RECORD",
        mode: "REPEATED",
        fields: [
          {
            name: "title",
            type: "STRING",
          },
          {
            name: "body",
            type: "STRING",
          },
        ],
      },

      { name: "jobDescription", type: "STRING" },
      { name: "eligiblePerson", type: "STRING" },
      { name: "workLocation", type: "STRING" },
      { name: "access", type: "STRING" },
      { name: "workingHours", type: "STRING" },
      { name: "salary", type: "STRING" },
      { name: "holidays", type: "STRING" },
      { name: "benefits", type: "STRING" },
      { name: "plannedNumberOfHires", type: "INTEGER" },
      { name: "applicationMethod", type: "STRING" },
      { name: "selectionProcess", type: "STRING" },

      { name: "contact", type: "STRING" },
      {
        name: "jobRemarks",
        type: "RECORD",
        mode: "REPEATED",
        fields: [
          {
            name: "title",
            type: "STRING",
          },
          {
            name: "body",
            type: "STRING",
          },
        ],
      },
      { name: "companyName", type: "STRING" },
      { name: "established", type: "STRING" },
      { name: "representative", type: "STRING" },
      { name: "capital", type: "STRING" },
      { name: "numberOfEmployees", type: "INTEGER" },
      { name: "address", type: "STRING" },
      { name: "amountOfSales", type: "STRING" },
      { name: "businessContent", type: "STRING" },
      { name: "homePage", type: "STRING" },
      {
        name: "companyRemarks",
        type: "RECORD",
        mode: "REPEATED",
        fields: [
          {
            name: "title",
            type: "STRING",
          },
          {
            name: "body",
            type: "STRING",
          },
        ],
      },
      {
        name: "createdAt",
        type: "DATETIME",
      },
    ],
  },
  location: "asia-northeast1",
};
