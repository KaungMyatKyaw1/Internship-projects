import * as dotenv from "dotenv";
dotenv.config();

import express from "express";
import { sleep } from "./lib/sleep";
import { getLinks } from "./lib/getLinks";
import { prepareTables } from "./lib/prepareTables";
import { checkEnv } from "./lib/checkEnv";
const app = express();

app.get("/getLinks", async (req, res, next) => {
  const unprovidedEnvs = checkEnv();
  if (unprovidedEnvs.length > 0) {
    return res.end();
  }
  await prepareTables();
  await sleep(120000);
  await getLinks();
  res.end();
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log("ポート", port, "でリッスンしている");
  console.log("クローラーシステムを起動している");
});
