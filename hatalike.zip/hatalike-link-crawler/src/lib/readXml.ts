import fs from "fs";
import { XMLParser } from "fast-xml-parser";

export const readXML = async (targetFile: string) => {
  const XMLdata = fs.readFileSync(targetFile, "utf-8");
  // console.log(XMLdata);
  const parser = new XMLParser();
  const jsonObj = parser.parse(XMLdata);
  return jsonObj;
};
