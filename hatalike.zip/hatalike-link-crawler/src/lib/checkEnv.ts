export const checkEnv = () => {
  //    project
  const projectId = process.env.PROJECT_ID;
  const datasetId = process.env.DATASET_ID;
  const region = process.env.REGION;

  // queues
  const jobQueue = process.env.JOB_QUEUE;

  // sitemap urls
  const sitemapUrl = process.env.SITEMAP_URL;

  // local sitemap dir
  const sitemapDir = process.env.SITEMAP_DIR;
  const sitemapFilter = process.env.SITEMAP_FILTER_STARTSWITH;

  // service
  const jobCrawlerService = process.env.JOB_CRAWLER_SERVICE;

  // service acc
  const taskServiceAcc = process.env.TASK_SERVICE_ACC;

  // tables
  const statusTableId = process.env.STATUS_TABLE_ID;
  const jobsTableId = process.env.JOBS_TABLE_ID;
  const totalCountTableId = process.env.TOTAL_COUNT_TABLE_ID;

  const requiredEnvVariables = [
    { name: "PROJECT_ID", env: projectId },
    { name: "DATASET_ID", env: datasetId },
    { name: "REGION", env: region },
    {
      name: "JOB_QUEUE",
      env: jobQueue,
    },
    {
      name: "SITEMAP_URL",
      env: sitemapUrl,
    },
    {
      name: "SITEMAP_DIR",
      env: sitemapDir,
    },
    {
      name: "SITEMAP_FILTER_STARTSWITH",
      env: sitemapFilter,
    },
    {
      name: "JOB_CRAWLER_SERVICE",
      env: jobCrawlerService,
    },
    {
      name: "TASK_SERVICE_ACC",
      env: taskServiceAcc,
    },
    {
      name: "STATUS_TABLE_ID",
      env: statusTableId,
    },
    {
      name: "JOBS_TABLE_ID",
      env: jobsTableId,
    },
    {
      name: "TOTAL_COUNT_TABLE_ID",
      env: totalCountTableId,
    },
  ];
  const unprovidedEnvs = requiredEnvVariables.filter((item) => {
    if (item.env === undefined || "") {
      console.log(`必須の「環境変数」は提供されていません。 -> ${item.name}`);
      return true;
    }
  });
  console.log("Unprovied envs " + unprovidedEnvs.length);
  return unprovidedEnvs;
};
