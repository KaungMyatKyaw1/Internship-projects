// Bigquery
import { BigQuery } from "@google-cloud/bigquery";

// moment-timezone
import moment from "moment-timezone";

import { createTaskForJobCrawler } from "./createTaskForJobCrawler";
import { downloadSitmapFile } from "./downloadSitemap";
import { generateRandomStr } from "./generateRandomStrFromDate";
import { readXML } from "./readXml";
import { saveToTotal } from "./saveToTotal";
import { sleep } from "./sleep";

export const getLinks = async () => {
  const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");
  const sitemapUrl = process.env.SITEMAP_URL;
  const sitemapDir = process.env.SITEMAP_DIR;
  const sitemapFilter = process.env.SITEMAP_FILTER_STARTSWITH;

  const datasetId = process.env.DATASET_ID;
  const totalCountTableId = process.env.TOTAL_COUNT_TABLE_ID + dateStr;

  await downloadSitmapFile(sitemapUrl, sitemapDir);
  await sleep(10000);
  const jsonResult = await readXML(sitemapDir);

  // console.log(JSON.stringify(jsonResult));

  const allUrls = jsonResult.urlset.url
    .filter((url: { loc: string; lastmod: string }) =>
      url.loc.startsWith(sitemapFilter)
    )
    .map((url: { loc: string; lastmod: string }) => url.loc);

  await saveToTotal({
    datasetId,
    tableId: totalCountTableId,
    row: {
      id: generateRandomStr(),
      count: allUrls.length,
      crawlerName: "hatalike",
      totalPages: null,
      jobsPerPage: null,
      insertedDate: BigQuery.date(
        moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD")
      ),
    },
  });

  for (const [idx, url] of allUrls.entries()) {
    console.log(`Index ${idx}`);
    await createTaskForJobCrawler(url);
  }
};
