import { BigQuery, BigQueryDate } from "@google-cloud/bigquery";
const bigqueryClient = new BigQuery();

interface Row {
  id: string;
  count: number;
  crawlerName: string;
  totalPages: number;
  jobsPerPage: number;
  insertedDate: BigQueryDate;
}

interface Args {
  datasetId: string;
  tableId: string;
  row: Row;
}

export const saveToTotal = async ({ datasetId, tableId, row }: Args) => {
  console.log(
    `「Bigquery」に挿入している。。。→ [datasetId　→ ${datasetId}], [tableId → ${tableId}]`
  );
  const rows = [row];
  await bigqueryClient
    // projectId
    .dataset(datasetId)
    .table(tableId)
    .insert(rows);
};
