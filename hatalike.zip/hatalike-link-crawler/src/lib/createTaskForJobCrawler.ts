// Imports the Google Cloud Tasks library.
import { CloudTasksClient } from "@google-cloud/tasks";
import moment from "moment-timezone";

// Instantiates a client.
const client = new CloudTasksClient();

export const createTaskForJobCrawler = async (url:string) => {
  // Construct the fully qualified queue name.
  const inSeconds = 1;
  const parent = client.queuePath(
    process.env.PROJECT_ID,
    process.env.REGION,
    process.env.JOB_QUEUE
  );
  const todayDate = moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD")


  const task: any = {
    httpRequest: {
      httpMethod: "GET",
      url: `${process.env.JOB_CRAWLER_SERVICE}/?url=${url}&date=${todayDate}`,
      oidcToken: {
        serviceAccountEmail: process.env.TASK_SERVICE_ACC,
      },
    },
    scheduleTime: {
      seconds: inSeconds,
    },
  };

  if (inSeconds) {
    // The time when the task is scheduled to be attempted.
    task.scheduleTime = {
      seconds: inSeconds + Date.now() / 1000,
    };
  }

  // Send create task request.
  console.log(`「${url}」送信タスクが実行されている。。。`);
  const request = { parent, task };
  const [response] = await client.createTask(request);
  console.log(`「${response.name}　タスク」を作成した。`);
};
