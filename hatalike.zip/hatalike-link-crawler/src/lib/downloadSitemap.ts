import https from "https";
import fs from "fs";

const { argv } = process;
// const [, , url, path] = argv;

export const downloadSitmapFile = async (url: string, path: string) => {
  if (url === undefined) {
    console.log(`The 'url' argument is missing.
	  You need to pass the file url as the first argument`);
    return;
  }

  if (path === undefined) {
    console.log(`The 'path' argument is missing.
	  You need to pass the save path as the second argument`);
    return;
  }

  https.get(url, (res) => {
    const writeStream = fs.createWriteStream(path);

    res.pipe(writeStream);

    writeStream.on("finish", () => {
      writeStream.close();
      console.log("Download Completed");
    });
  });
};
