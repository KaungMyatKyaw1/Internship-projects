import { BigQuery } from "@google-cloud/bigquery";
import { STATUS_TABLE_SCHEMA } from "../../schemas/status-schema";
import { JOB_TABLE_SCHEMA } from "../../schemas/job-schema";
import { TOTAL_COUNT_TABLE_SCHEMA } from "../../schemas/total-count-schema";

import moment from "moment-timezone";

export const prepareTables = async () => {
  const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");
  const datasetId = process.env.DATASET_ID;
  const statusTableId = process.env.STATUS_TABLE_ID + dateStr;
  const jobTableId = process.env.JOBS_TABLE_ID + dateStr;
  const totalCountTableId = process.env.TOTAL_COUNT_TABLE_ID + dateStr;

  const bigquery = new BigQuery();
  console.log("Preparing tables");
  await bigquery
    .dataset(datasetId)
    .createTable(statusTableId, STATUS_TABLE_SCHEMA);
  await bigquery.dataset(datasetId).createTable(jobTableId, JOB_TABLE_SCHEMA);
  await bigquery
    .dataset(datasetId)
    .createTable(totalCountTableId, TOTAL_COUNT_TABLE_SCHEMA);

  return;
};
