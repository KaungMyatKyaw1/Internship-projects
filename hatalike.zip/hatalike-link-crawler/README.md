# doda-job-crawler


## Development

Create .env from .env.sample
```
npm run build
npm start
```