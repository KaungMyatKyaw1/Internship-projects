// jsdom
import got from "got";
import { JSDOM } from "jsdom";
import { writeFile } from "./writeFile";

export const getDetailPageDocument = async (url: string) => {
  try {
    const response = await got(url);
    const body = response.body;
    const start = '<ul class="bl_cardWrap js_cardTwoColumn is-show">';
    const end =
      '<ul class="bl_cardWrap bl_cardWrap-oneColumn js_cardOneColumn">';

    const requiredHTML =
      body.substring(body.indexOf(start), body.indexOf(end) + end.length) +
      "</ul>";
    // await writeFile(requiredHTML);

    const { document } = new JSDOM(requiredHTML).window;
    return document;
  } catch (error) {
    console.log(error);
  }
};

export const getHomeDocument = async (url: string) => {
  try {
    const response = await got(url);
    const body = response.body;

    const start = '<span class="page-numbers dots">…</span>';
    const end = "<span>次のページ</span>";

    const requiredHTML =
      body.substring(body.indexOf(start), body.indexOf(end) + end.length) +
      "</a>";
    // await writeFile(requiredHTML);

    const { document } = new JSDOM(requiredHTML).window;
    return document;
  } catch (error) {
    console.log(error);
  }
};
