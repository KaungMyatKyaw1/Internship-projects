import * as dotenv from "dotenv";
dotenv.config();
import { createTaskForLinkCrawler } from "./createTaskForLinkCrawler";
import { getHomeDocument } from "./getDocument";

interface Args {
  url: string;
  keyword: string;
}

export const sleep = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));

export const crawlPages = async () => {
  const hokkaidoUrl = process.env.HOKKAIDO_URL;

  const document = await getHomeDocument(hokkaidoUrl);
  const lastPage = Number(
    document.querySelector(".dots").nextElementSibling.textContent
  );
  console.log("Last page " + lastPage);

  for (let page = 1; page <= lastPage; page++) {
    // console.log("Creating task for " + page);
    await createTaskForLinkCrawler(page);
  }
};
