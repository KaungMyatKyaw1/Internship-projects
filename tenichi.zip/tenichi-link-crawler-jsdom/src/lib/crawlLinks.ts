import { createTaskForJobCrawler } from "./createTaskForJobCrawler";
import { getDetailPageDocument } from "./getDocument";

export const crawlLinks = async (pageNo: number) => {
  const hokkaidoUrl = process.env.HOKKAIDO_URL;
  const homeUrl = process.env.HOME_URL;
  const document = await getDetailPageDocument(`${hokkaidoUrl}p_${pageNo}`);
  const hrefs = Array.from(
    document.querySelectorAll(".js_cardTwoColumn .bl_btn__orange")
  ).map((anchor: HTMLAnchorElement) => anchor.href);

  const fullUrls = hrefs.map((link) => `${homeUrl}${link}`);
  for (const url of fullUrls) {
    // console.log("creating task for url " + url + " page no is " + pageNo);
    await createTaskForJobCrawler({
      url,
      pageNo,
    });
  }
};
