import { BigQueryDatetime, BigQueryDate } from "@google-cloud/bigquery";

// COMPANY INFORMATION TYPES
export interface CompanyInformationRecord {
  title: string;
  body: string;
  imgUrl: string;
}
export interface BusinessContentRecord {
  title: string;
  body: string;
  imgUrl: string;
}
export interface WorkInformationRecord {
  title: string;
  body: string;
  imgUrl: string;
}
export interface FrequentQuestionsAnswersRecord {
  question: string;
  answer: string;
}
export interface InterviewsRecord {
  question: string;
  answer: string;
}
export interface BenefitsRecord {
  title: string;
  body: string;
}
export interface CompanyMap {
  lat: number;
  lng: number;
}

// JOB INFORMATION TYPES
export interface JobImgsRecord {
  url: string;
}
export interface JobCharacteristicsRecord {
  text: string;
}
export interface WorkingEnvironmentTags {
  text: string;
}

// COMPANY SCHEMA
export interface Company {
  companyId: string;
  keyword : string;
  companyName: string;
  address: string;
  representative: string;
  map: CompanyMap;
  homePage: string;
  appealText: string;
  companyInformation: CompanyInformationRecord[];
  businessContents: BusinessContentRecord[];
  workInformation: WorkInformationRecord[];
  frequentQuestionsAnswers: FrequentQuestionsAnswersRecord[];
  interviews: InterviewsRecord[];
  benefits: BenefitsRecord[];
}

// JOB SCHEMA
export interface Job {
  jobId: string;
  keyword : string;
  companyId: string;
  hiringStatus: string;
  positionTitle: string;
  jobImgUrls: JobImgsRecord[];
  occupation: string;
  salary: string;
  benefits: string;
  transportationExpenses: string;
  workLocation: string;
  access: string;
  qualifications: string;
  workingHours: string;
  holidays: string;
  workingPeriods: string;
  shiftInformation: string;
  trialTraining: string;
  workingDays: string;
  jobContent: string;
  jobCharacteristics: JobCharacteristicsRecord[];
  workingEnvironmentDetails: WorkingEnvironmentTags[];
  incomeExample: string;
  flowAfterApplication: string;
  plannedNumberOfHires: string;
  phoneNumber: string;
  createdAt: BigQueryDatetime;
}

// STATUS SCHEMA
export interface Status {
  jobId: string;
  companyId: string;
  url: string;
  crawlStatus: string;
  createdAt: BigQueryDatetime;
}

// TOTAL SCHEMA
export interface TotalCount {
  id: string;
  count: number;
  crawlerName: string;
  totalPages: number;
  jobsPerPage: number;
  insertedDate: BigQueryDate;
}
