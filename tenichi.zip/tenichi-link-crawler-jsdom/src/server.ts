import * as dotenv from "dotenv";
dotenv.config();

import express from "express";

import { crawlPages, sleep } from "./lib/crawlPages";
import { crawlLinks } from "./lib/crawlLinks";
import { prepareTables } from "./lib/prepareTables";
const app = express();

app.get("/crawl-pages", async (req, res, next) => {
  await prepareTables();
  await sleep(120000);
  await crawlPages();
  res.end();
});
app.get("/crawl-links", async (req, res, next) => {
  const pageNo = Number(req.query.pageNo);
  await crawlLinks(pageNo);
  res.end();
});
const port = 8081;
app.listen(port, () => {
  console.log("ポート", port, "でリッスンしている");
  console.log("クローラーシステムを起動している");
});
