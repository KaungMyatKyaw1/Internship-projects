export const JOB_TABLE_SCHEMA: any = {
  sourceFormat: "NEWLINE_DELIMITED_JSON",
  schema: {
    fields: [
      { name: "jobId", type: "STRING" },
      { name: "subdomain", type: "STRING" },
      { name: "companyName", type: "STRING" },
      { name: "jobTitle", type: "STRING" },
      { name: "jobImgUrl", type: "STRING" },
      { name: "postUpdatedDateStr", type: "STRING" },
      { name: "postUpdatedDate", type: "DATE" },
      { name: "occupation", type: "STRING" },
      { name: "employmentStatus", type: "STRING" },
      { name: "salary", type: "STRING" },
      {
        name: "features",
        type: "RECORD",
        mode: "REPEATED",
        fields: [
          {
            name: "feature",
            type: "STRING",
          },
        ],
      },

      { name: "workLocation", type: "STRING" },
      {
        name: "nearestStations",
        type: "STRING",
      },
      { name: "workingHours", type: "STRING" },
      { name: "holidays", type: "STRING" },
      { name: "recruitmentBackground", type: "STRING" },
      { name: "jobDescription", type: "STRING" },
      { name: "benefits", type: "STRING" },
      { name: "appealPoints", type: "STRING" },
      { name: "selectionProcedure", type: "STRING" },
      { name: "aboutInterview", type: "STRING" },
      {
        name: "createdAt",
        type: "DATETIME",
      },
    ],
  },
  location: "asia-northeast1",
};
