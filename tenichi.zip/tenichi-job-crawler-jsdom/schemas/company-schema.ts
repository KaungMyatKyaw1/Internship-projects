export const COMPANY_TABLE_SCHEMA: any = {
  sourceFormat: "NEWLINE_DELIMITED_JSON",
  schema: {
    fields: [
      { name: "subdomain", type: "STRING" },
      { name: "companyName", type: "STRING" },
      { name: "capitalInt", type: "INTEGER" },
      { name: "capitalStr", type: "STRING" },
      { name: "businessContent", type: "STRING" },
      { name: "numberOfEmployees", type: "INTEGER" },
      { name: "headOfficeLocation", type: "STRING" },
      { name: "homePage", type: "STRING" },
      {
        name: "createdAt",
        type: "DATETIME",
      },
    ],
  },
  location: "asia-northeast1",
};
