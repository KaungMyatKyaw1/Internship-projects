import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment-timezone";
import { Job, Company } from "../data-definition";

// extract functions
import { getDataFromTable } from "./extractFunctions";

interface CrawlFromTenichiArgs {
  jobUrl: string;
  document: Document;
}

export const crawlCompany = async ({
  jobUrl,
  document,
}: CrawlFromTenichiArgs) => {
  console.log("Crawling Company Information");
  const tables: HTMLTableElement[] = Array.from(
    document.querySelectorAll(".bl_table")
  );

  // ***** COMPANY INFORMATION ****** //

  // companyName
  const companyName = getDataFromTable({
    thText: "社名",
    table: tables[2],
  });
  // capitalInt
  const capitalInt = parseInt(
    getDataFromTable({
      thText: "資本金",
      table: tables[2],
    }).replaceAll(",", ""),
    10
  );
  // capitalStr
  const capitalStr = getDataFromTable({
    thText: "資本金",
    table: tables[2],
  });
  // businessContent
  const businessContent = getDataFromTable({
    thText: "事業内容",
    table: tables[2],
  });

  // numberOfEmployees
  const numberOfEmployees = parseInt(
    getDataFromTable({
      thText: "従業員数",
      table: tables[2],
    }).replaceAll(",", ""),
    10
  );

  // headOfficeLocation
  const headOfficeLocation = getDataFromTable({
    thText: "本社所在地",
    table: tables[2],
  });
  // homePage
  const homePage = getDataFromTable({
    thText: "URL",
    table: tables[2],
  });

  return {
    subdomain : "",
    companyName,
    capitalInt,
    capitalStr,
    businessContent,
    numberOfEmployees,
    headOfficeLocation,
    homePage,
    createdAt: BigQuery.datetime(
      moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
    ),
  };
};

export const crawlJob = async ({ jobUrl, document }: CrawlFromTenichiArgs) => {
  // crawling in document
  console.log("Crawling Tenichi Job");

  // ***** JOB INFORMATION ***** //

  // jobId
  const urlParts = jobUrl.split("/");
  const jobId = Number(urlParts[urlParts.length - 1]);

  const subdomain = "";

  // jobTitle
  const jobTitle = document.querySelector(".el_title")
    ? document.querySelector(".el_title").textContent.trim()
    : "";

  // jobImgUrl
  const picture = document.querySelector(".bl_contents_img");
  const jobImgUrl = picture
    ? picture.querySelector("img").getAttribute("data-src")
    : "";

  // postUpdatedDateStr
  const dateEle = document.querySelector(".el_updated_at");
  const postUpdatedDateStr = dateEle
    ? dateEle.textContent.trim().split("：")[1]
    : "";

  // postUpdatedDate
  // 2022年03月30日
  // new Date("2022-03-15")
  const dateString = postUpdatedDateStr
    .replace("年", "-")
    .replace("月", "-")
    .replace("日", "");

  const postUpdatedDate = BigQuery.date(
    moment.tz(moment(new Date(dateString)), "Asia/Tokyo").format("YYYY-MM-DD")
  );

  const tables: HTMLTableElement[] = Array.from(
    document.querySelectorAll(".bl_table")
  );

  // occupation
  const occupation = getDataFromTable({
    thText: "職種",
    table: tables[1],
  });
  // employmentStatus
  const employmentStatus = getDataFromTable({
    thText: "雇用形態",
    table: tables[1],
  });
  // salary
  const salary = getDataFromTable({
    thText: "年収・給与",
    table: tables[1],
  });
  // features
  const features = getDataFromTable({
    thText: "特徴",
    table: tables[1],
  })
    .split(" / ")
    .map((feature) => {
      return {
        feature: feature.replace(/\s/g, ""),
      };
    });

  // workLocation
  const workLocation = getDataFromTable({
    thText: "勤務地",
    table: tables[1],
  });

  // nearestStations
  const nearestStations = getDataFromTable({
    thText: "最寄駅",
    table: tables[1],
  });

  // workingHours
  const workingHours = getDataFromTable({
    thText: "勤務時間",
    table: tables[1],
  });

  // holidays
  const holidays = getDataFromTable({
    thText: "休日・休暇",
    table: tables[1],
  });

  // recruitmentBackground
  const recruitmentBackground = getDataFromTable({
    thText: "募集背景",
    table: tables[1],
  });

  // jobDescription
  const jobDescription = getDataFromTable({
    thText: "仕事内容",
    table: tables[1],
  });
  // benefits
  const benefits = getDataFromTable({
    thText: "待遇・福利厚生",
    table: tables[1],
  });
  // appealPoints
  const appealPoints = getDataFromTable({
    thText: "アピールポイント",
    table: tables[1],
  });
  // selectionProcedure
  const selectionProcedure = getDataFromTable({
    thText: "選考手順",
    table: tables[1],
  });
  // aboutInterview
  const aboutInterview = getDataFromTable({
    thText: "面接地",
    table: tables[1],
  });

  // companyName
  const companyName = getDataFromTable({
    thText: "社名",
    table: tables[2],
  });

  return {
    jobId,
    subdomain,
    companyName,
    jobTitle,
    jobImgUrl,
    postUpdatedDateStr,
    postUpdatedDate,
    occupation,
    employmentStatus,
    salary,
    features,
    workLocation,
    nearestStations,
    workingHours,
    holidays,
    recruitmentBackground,
    jobDescription,
    benefits,
    appealPoints,
    selectionProcedure,
    aboutInterview,
    createdAt: BigQuery.datetime(
      moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
    ),
  };
};