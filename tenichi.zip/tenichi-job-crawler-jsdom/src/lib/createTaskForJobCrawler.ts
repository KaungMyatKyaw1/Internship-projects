// Imports the Google Cloud Tasks library.
import { CloudTasksClient } from "@google-cloud/tasks";
import { Company } from "../data-definition";
import moment from "moment-timezone";

interface CreateTaskArgs {
  jobUrl: string;
  pageNo: number;
  subdomain: string;
  company: Company;
}

// Instantiates a client.
const client = new CloudTasksClient();

export const createTaskForJobCrawler = async ({
  jobUrl,
  pageNo,
  subdomain,
  company,
}: CreateTaskArgs) => {
  // Construct the fully qualified queue name.
  const inSeconds = 1;
  const parent = client.queuePath(
    process.env.PROJECT_ID,
    process.env.REGION,
    process.env.JOB_QUEUE
  );

  const todayDate = moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD");
  const companyName = company.companyName
  const payload = {
    jobUrl,
    pageNo,
    companyName,
    subdomain,
    todayDate
  };

  const task: any = {
    httpRequest: {
      httpMethod: "POST",
      url: `${process.env.JOB_CRAWLER_SERVICE}/crawl-ats-job/`,
      body: Buffer.from(JSON.stringify(payload)).toString("base64"),
      headers: {
        "content-type": "application/octet-stream",
      },
      oidcToken: {
        serviceAccountEmail: process.env.TASK_SERVICE_ACC,
      },
    },
    scheduleTime: {
      seconds: inSeconds,
    },
  };

  if (inSeconds) {
    // The time when the task is scheduled to be attempted.
    task.scheduleTime = {
      seconds: inSeconds + Date.now() / 1000,
    };
  }

  // Send create task request.
  console.log(`「${jobUrl}」送信タスクが実行されている。。。`);
  const request = { parent, task };
  const [response] = await client.createTask(request);
  console.log(`「${response.name}　タスク」を作成した。`);
};
