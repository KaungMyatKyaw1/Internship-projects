import fs from "fs";

export const writeFile = async (data: string) => {
  fs.writeFile("index.txt", data, function (err) {
    if (err) return console.log(err);
    console.log("file wrote.");
  });
};
