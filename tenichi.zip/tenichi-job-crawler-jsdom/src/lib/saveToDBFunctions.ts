// data definition
import { Status, Job, Company, TotalCount } from "../data-definition";

// schema
import { STATUS_TABLE_SCHEMA } from "../../schemas/status-schema";
import { COMPANY_TABLE_SCHEMA } from "../../schemas/company-schema";
import { JOB_TABLE_SCHEMA } from "../../schemas/job-schema";
import { TOTAL_COUNT_TABLE_SCHEMA } from "../../schemas/total-count-schema";

// bigquery
import { BigQuery } from "@google-cloud/bigquery";

import { sleep } from "./crawl";

interface InsertStatus {
  datasetId: string;
  tableId: string;
  row: Status;
}
interface InsertJob {
  datasetId: string;
  tableId: string;
  row: Job;
}
interface InsertCompany {
  datasetId: string;
  tableId: string;
  row: Company;
}
interface InsertTotalCount {
  datasetId: string;
  tableId: string;
  row: TotalCount;
}

const bigquery = new BigQuery();

export const insertStatus = async ({
  datasetId,
  tableId,
  row,
}: InsertStatus) => {
  console.log(("insering status"));

  const rows = [row];
  try {
    console.log(
      `ステータステーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Subdomain → ${
        row.subdomain ? row.subdomain : "「サブドメインはない」"
      }], [Job ID　→ ${row.jobId}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    // console.log(JSON.stringify(error));
    if (error.code === 404) {
      await bigquery
        .dataset(datasetId)
        .createTable(tableId, STATUS_TABLE_SCHEMA);
      await sleep(120000); // wait table is not available yet (2 min)
      await bigquery.dataset(datasetId).table(tableId).insert(rows);
    }
  }
};

export const insertJob = async ({ datasetId, tableId, row }: InsertJob) => {
  console.log("inserting job");

  const rows = [row];
  try {
    console.log(
      `ジョブテーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Subdomain → ${
        row.subdomain ? row.subdomain : "「サブドメインはない」"
      }], [Company Name → ${row.companyName}] , [Job ID　→ ${row.jobId}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    // console.log(JSON.stringify(error));
    if (error.code === 404) {
      await bigquery.dataset(datasetId).createTable(tableId, JOB_TABLE_SCHEMA);
      await sleep(120000); // wait table is not available yet (2 min)
      await bigquery.dataset(datasetId).table(tableId).insert(rows);
      return false;
    }
  }
};

export const insertCompany = async ({
  datasetId,
  tableId,
  row,
}: InsertCompany) => {
  console.log("Inserting company");

  const rows = [row];
  try {
    console.log(
      `ジョブテーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Subdomain → ${
        row.subdomain ? row.subdomain : "「サブドメインはない」"
      }], [Company Name　→ ${row.companyName}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    // console.log(JSON.stringify(error));
    if (error.code === 404) {
      await bigquery
        .dataset(datasetId)
        .createTable(tableId, COMPANY_TABLE_SCHEMA);
      await sleep(120000); // wait table is not available yet (2 min)
      await bigquery.dataset(datasetId).table(tableId).insert(rows);
    }
  }
};

export const insertTotalCount = async ({
  datasetId,
  tableId,
  row,
}: InsertTotalCount) => {
  console.log("inserting total count");

  const rows = [row];
  try {
    console.log(
      `ジョブテーブルに保存している。 [Dataset ID → ${datasetId}], [Table ID → ${tableId}], [Subdomain → ${
        row.subdomain ? row.subdomain : "「サブドメインはない」"
      }], [Company Name　→ ${row.companyName}]`
    );
    return await bigquery
      // projectId
      .dataset(datasetId)
      .table(tableId)
      .insert(rows);
  } catch (error) {
    // console.log(JSON.stringify(error));
    if (error.code === 404) {
      await bigquery
        .dataset(datasetId)
        .createTable(tableId, TOTAL_COUNT_TABLE_SCHEMA);
      await sleep(120000); // wait table is not available yet (2 min)
      await bigquery.dataset(datasetId).table(tableId).insert(rows);
    }
  }
};
