import { Company } from "../data-definition";
import { getDocument } from "./getDocument";

export const getInfoFromRecruitSite = async ({
  recruitmentSiteUrl,
  company,
}: {
  recruitmentSiteUrl: string;
  company: Company;
}) => {

  console.log("get info from recruitsite");
  const url = new URL(recruitmentSiteUrl);
  if (url.hostname !== "ten.1049.cc") {

    return {
      subdomain: "",
      totalJobs: null,
      jobsPerPage: null,
      totalPages: null,
    };
  }

  const splittedUrl = recruitmentSiteUrl
    .split("/")
    .filter((part) => part !== "");
  const subdomain = splittedUrl[splittedUrl.length - 1];

  const document = await getDocument(`${recruitmentSiteUrl}search/area_1/p_1`);
  // if(document == null){

  //   return {
  //     subdomain: "",
  //     totalJobs: null,
  //     jobsPerPage: null,
  //     totalPages: null,
  //   };
  // }
  const totalJobs = Number(document.querySelector(".count em").textContent);
  const jobsPerPage = 20;

  const totalPages = Math.ceil(totalJobs / 20);

  console.log("Total Jobs -> " + totalJobs);
  console.log("Total Jobs Per Page -> " + jobsPerPage);
  console.log("Total Pages -> " + totalPages);

  return { subdomain, totalJobs, jobsPerPage, totalPages };
};
