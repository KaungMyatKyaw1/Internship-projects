import moment from "moment-timezone";

export const checkEnv = () => {
  const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");

  // project
  const projectId = process.env.PROJECT_ID;
  const datasetId = process.env.DATASET_ID;
  const region = process.env.REGION;

  // tables
  const statusTableId = process.env.STATUS_TABLE_ID + dateStr;
  const jobTableId = process.env.JOB_TABLE_ID + dateStr;
  const companyTableId = process.env.COMPANY_TABLE_ID + dateStr;
  const totalTableId = process.env.TOTAL_COUNT_TABLE_ID + dateStr;

  // queue
  const jobQueue = process.env.JOB_QUEUE;
  const jobCrawlerService = process.env.JOB_CRAWLER_SERVICE;
  const taskServiceAcc = process.env.TASK_SERVICE_ACC;

  const requiredEnvVariables = [
    { name: "PROJECT_ID", env: projectId },
    { name: "DATASET_ID", env: datasetId },
    {
      name: "REGION",
      env: region,
    },
    {
      name: "STATUS_TABLE_ID",
      env: statusTableId,
    },
    {
      name: "JOBS_TABLE_ID",
      env: jobTableId,
    },
    { name: "COMPANY_TABLE_ID", env: companyTableId },

    {
      name: "TOTAL_COUNT_TABLE_ID",
      env: totalTableId,
    },
    {
      name: "JOB_QUEUE",
      env: jobQueue,
    },
    {
      name: "JOB_CRAWLER_SERVICE",
      env: jobCrawlerService,
    },
    {
      name: "TASK_SERVICE_ACC",
      env: taskServiceAcc,
    },
  ];
  const unprovidedEnvs = requiredEnvVariables.filter((item) => {
    if (item.env === undefined || "") {
      console.log(`必須の「環境変数」は提供されていません。 -> ${item.name}`);
      return true;
    }
  });
  console.log("Unprovied envs " + unprovidedEnvs.length);
  return unprovidedEnvs;
};
