import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment-timezone";
import { Company, Job, Status, TotalCount } from "../data-definition";
import {
  insertCompany,
  insertStatus,
  insertTotalCount,
} from "./saveToDBFunctions";

interface SaveToDBArgs {
  datasetId: string;
  statusTableId: string;
  status: Status;
  companyTableId: string;
  company: Company;
  totalTableId: string;
  totalCount: TotalCount;
}

export const saveToDB = async ({
  datasetId,
  statusTableId,
  status,
  companyTableId,
  company,
  totalTableId,
  totalCount,
}: SaveToDBArgs) => {
  console.log("save to db");

  if (!status) {

    await Promise.all([
      // save to company
      insertCompany({
        datasetId,
        tableId: companyTableId,
        row: company,
      }),
      // save to total_count
      insertTotalCount({
        datasetId,
        tableId: totalTableId,
        row: totalCount,
      }),
    ]);

    // save to status
    await insertStatus({
      datasetId,
      tableId: statusTableId,
      row: status,
    });
    return;
  }

  await Promise.all([
    // save to company
    insertCompany({
      datasetId,
      tableId: companyTableId,
      row: company,
    }),
    // save to total_count
    insertTotalCount({
      datasetId,
      tableId: totalTableId,
      row: totalCount,
    }),
  ]);
  return;
};
