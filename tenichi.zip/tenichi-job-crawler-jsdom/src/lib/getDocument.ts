// jsdom
import { request, response } from "express";
import got from "got";
import { JSDOM } from "jsdom";
import { writeFile } from "./writeFile";

export const getDocument = async (url: string) => {
  try {
    const response = await got(url);
    const body = response.body;

    // await writeFile(body);

    const { document } = new JSDOM(body).window;

    return document;
  } catch (error) {
    const str = JSON.stringify(error)

    if(str.includes("HTTPError")){
      // console.log("Subdomain link 404 error");
      return
    }
  }
};

export const getJobArticleDocument = async (url: string) => {
  try {
    const response = await got(url);
    const body = response.body;

    const start = '<article class="ly_cont ly_cont__single">';
    const end = "</article>";

    const requiredHTML = body.substring(
      body.indexOf(start),
      body.indexOf(end) + end.length
    );

    // console.log("response is"+ response);
    // console.log("body is"+body);
    // console.log(".."+requiredHTML);



    // const exceptedHTML =
    //   body.substring(0, body.indexOf(start)) +
    //   body.substring(body.indexOf(end) + end.length);

    // await writeFile(requiredHTML);

    const { document } = new JSDOM(requiredHTML).window;
    return document;
  } catch (error) {
    console.log(error);
  }
};
