import moment from "moment-timezone";
import { BigQuery } from "@google-cloud/bigquery";

interface CheckCompanyArgs {
  companyName: string;
  homePage: string;
}

export const checkCompany = async ({
  companyName,
  homePage
}: CheckCompanyArgs) => {
  const bigquery = new BigQuery();
  console.log("checking company");

  const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");
  // project
  const projectId = process.env.PROJECT_ID;
  const datasetId = process.env.DATASET_ID;
  const companyTableId = process.env.COMPANY_TABLE_ID + dateStr;

  const checkCompanyQuery = `SELECT count(1) as count FROM ${projectId}.${datasetId}.${companyTableId} WHERE companyName="${companyName}" AND homePage="${homePage}"`;

  const getSubdomainCount = {
    query: checkCompanyQuery,
    location: "asia-northeast1",
  };

  let result;
  // Run the query as a job
  try {
    [result] = await bigquery.createQueryJob(getSubdomainCount);
  } catch (err) {
    console.log(err);
    return {
      isTableExist: false,
      companyCountInDb: 0,
    };
  }

  // Wait for the query to finish
  const [rows] = await result.getQueryResults();

  if (!rows[0]) {
    return {
      isTableExist: false,
      companyCountInDb: 0,
    };
  }
  // Print the results
  return { isTableExist: true, companyCountInDb: Number(rows[0].count) };
};
