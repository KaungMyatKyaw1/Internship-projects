// bigquery and moment
import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment-timezone";

// document
import { getDocument } from "./getDocument";

// extract functions
import {
  getDataFromTable,
  getDataArrayFromTable,
} from "../lib/extractFunctions";

// save to DB Functions
import {
  insertJob,
  insertStatus,
} from "./saveToDBFunctions";

interface CrawlRecruitSiteArgs {
  jobUrl: string;
  subdomain: string;
  pageNo: number;
  companyName: string;
  yearMonthDay: string;
}

export const crawlRecruitSiteJob = async ({
  jobUrl,
  subdomain,
  pageNo,
  companyName,
  yearMonthDay,
}: CrawlRecruitSiteArgs) => {
  console.log("inside crawlRecruitSiteJob function");

  // const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");

  // project
  const projectId = process.env.PROJECT_ID;
  const datasetId = process.env.DATASET_ID;
  const region = process.env.REGION;

  // tables
  const statusTableId = process.env.STATUS_TABLE_ID + "_" + yearMonthDay;
  const jobTableId = process.env.JOB_TABLE_ID + "_" + yearMonthDay;
  const companyTableId = process.env.COMPANY_TABLE_ID + "_" + yearMonthDay;
  const totalTableId = process.env.TOTAL_COUNT_TABLE_ID + "_" + yearMonthDay;

  // queue
  const jobQueue = process.env.JOB_QUEUE;
  const jobCrawlerService = process.env.JOB_CRAWLER_SERVICE;
  const taskServiceAcc = process.env.TASK_SERVICE_ACC;

  const document = await getDocument(jobUrl);

  // ***** JOB INFORMATION ***** //

  // jobId
  const urlParts = jobUrl.split("/").filter((part) => part !== "");
  const jobId = Number(urlParts[urlParts.length - 1]);

  // jobTitle
  const jobTitle = document.querySelector(".title_bg")
    ? document.querySelector(".title_bg").textContent.trim()
    : "";

  // jobImgUrl
  const jobImgUrlParent = document.querySelector(".main_gazo");
  const jobImgUrl = jobImgUrlParent
    ? jobImgUrlParent.querySelector("img").src
    : "";

  // postUpdatedDateStr
  const dateEle = document.querySelector(".updated");
  const postUpdatedDateStr = dateEle
    ? dateEle.textContent.trim().split("：")[1]
    : "";

  // postUpdatedDate
  // 2022年03月30日
  // new Date("2022-03-15")
  const dateString = postUpdatedDateStr
    .replace("年", "-")
    .replace("月", "-")
    .replace("日", "");
  const postUpdatedDate = BigQuery.date(
    moment.tz(moment(new Date(dateString)), "Asia/Tokyo").format("YYYY-MM-DD")
  );

  const introTable: HTMLTableElement = document.querySelector(
    ".introduction_right table"
  );
  const areaDetailTable: HTMLTableElement =
    document.querySelector(".area_detail table");

  // occupation
  // occupation
  const occupation = getDataFromTable({
    thText: "職種",
    table: introTable,
  });
  // employmentStatus
  const employmentStatus = getDataFromTable({
    thText: "雇用形態",
    table: introTable,
  });
  // salary
  const salary = getDataFromTable({
    thText: "給与",
    table: introTable,
  });
  // features
  const features = getDataArrayFromTable({
    thText: "特徴",
    table: introTable,
  });
  // workLocation
  const workLocation = getDataFromTable({
    thText: "勤務地",
    table: introTable,
  });
  // nearestStations
  const nearestStations = getDataFromTable({
    thText: "最寄駅",
    table: introTable,
  });
  // workingHours
  const workingHours = getDataFromTable({
    thText: "勤務時間",
    table: introTable,
  });
  // holidays
  const holidays = getDataFromTable({
    thText: "休日・休暇",
    table: introTable,
  });

  // recruitmentBackground
  const recruitmentBackground = getDataFromTable({
    thText: "募集背景",
    table: areaDetailTable,
  });

  // jobDescription
  const jobDescription = getDataFromTable({
    thText: "仕事内容",
    table: areaDetailTable,
  });
  // benefits
  const benefits = getDataFromTable({
    thText: "待遇・福利厚生",
    table: areaDetailTable,
  });
  // appealPoints
  const appealPoints = getDataFromTable({
    thText: "アピールポイント",
    table: areaDetailTable,
  });
  // selectionProcedure
  const selectionProcedure = getDataFromTable({
    thText: "選考手順",
    table: areaDetailTable,
  });
  // aboutInterview
  const aboutInterview = getDataFromTable({
    thText: "面接地",
    table: areaDetailTable,
  });

  const job = {
    jobId,
    subdomain,
    companyName,
    jobTitle,
    jobImgUrl,
    postUpdatedDateStr,
    postUpdatedDate,
    occupation,
    employmentStatus,
    salary,
    features,
    workLocation,
    nearestStations,
    workingHours,
    holidays,
    recruitmentBackground,
    jobDescription,
    benefits,
    appealPoints,
    selectionProcedure,
    aboutInterview,
    createdAt: BigQuery.datetime(
      moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
    ),
  };

  // console.log(JSON.stringify(job));

  // save to job
  const isSuccess = await insertJob({
    datasetId,
    tableId: jobTableId,
    row: job,
  });

  // save to status
  await insertStatus({
    datasetId,
    tableId: statusTableId,
    row: {
      jobId: job.jobId,
      subdomain,
      companyName,
      url: jobUrl,
      pageNo,
      crawlStatus: isSuccess ? "成功" : "失敗",
      createdAt: BigQuery.datetime(
        moment
          .tz(moment(new Date()), "Asia/Tokyo")
          .format("YYYY-MM-DDTHH:mm:ss")
      ),
    },
  });

  return;

};
