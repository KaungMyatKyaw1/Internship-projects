import * as dotenv from "dotenv";
dotenv.config();
import { getDocument, getJobArticleDocument } from "./getDocument";
import { crawlCompany, crawlJob } from "./crawlFromTenichi";

import { getInfoFromRecruitSite } from "./getInfoFromRecruitSite";
import { createTaskForJobCrawler } from "./createTaskForJobCrawler";

import { insertJob } from "./saveToDBFunctions";

import moment from "moment-timezone";
import { BigQuery } from "@google-cloud/bigquery";
import { checkCompany } from "./checkCompany";
import { saveToDB } from "./saveToDB";
import { Status, TotalCount } from "../data-definition";

interface CrawlArgs {
  jobUrl: string;
  pageNo: number;
}

export const sleep = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));

  export const crawl = async ({ jobUrl, pageNo }: CrawlArgs) => {
  const dateStr = "_" + moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");

  // project
  const projectId = process.env.PROJECT_ID;
  const datasetId = process.env.DATASET_ID;
  const region = process.env.REGION;

  // tables
  const statusTableId = process.env.STATUS_TABLE_ID + dateStr;
  const jobTableId = process.env.JOB_TABLE_ID + dateStr;
  const companyTableId = process.env.COMPANY_TABLE_ID + dateStr;
  const totalTableId = process.env.TOTAL_COUNT_TABLE_ID + dateStr;

  // queue
  const jobQueue = process.env.JOB_QUEUE;
  const jobCrawlerService = process.env.JOB_CRAWLER_SERVICE;
  const taskServiceAcc = process.env.TASK_SERVICE_ACC;

  const document = await getJobArticleDocument(jobUrl);

  const [company, job] = await Promise.all([
    crawlCompany({
      jobUrl,
      document,
    }),
    crawlJob({
      jobUrl,
      document,
    }),
  ]);
  const status: Status = {
    jobId: job.jobId,
    subdomain: job.subdomain,
    companyName: job.companyName,
    url: jobUrl,
    pageNo,
    crawlStatus: "",
    createdAt: BigQuery.datetime(
      moment.tz(moment(new Date()), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
    ),
  };
  const totalCount: TotalCount = {
    subdomain: job.subdomain,
    companyName: job.companyName,
    count: 1,
    crawlerName: "tenichi",
    totalPages: null,
    jobsPerPage: null,
    insertedDate: BigQuery.date(
      moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD")

    ),
  };

  const { isTableExist, companyCountInDb } = await checkCompany({
    companyName: company.companyName,
    homePage: company.homePage,
  });

  const topInfoTable = document.querySelector(".bl_table");
  if (!topInfoTable) {
    // save to job
    const isSuccess = await insertJob({
      datasetId,
      tableId: jobTableId,
      row: job,
    });
    status.crawlStatus = isSuccess ? "成功" : "失敗";
    // save status, company, total_count
    await saveToDB({
      datasetId,
      statusTableId,
      status,
      companyTableId,
      company,
      totalTableId,
      totalCount,
    });
    return;
  }
  const recruitSiteTrEle = Array.from(
    topInfoTable.querySelectorAll("tr")
  ).filter(
    (tr) => tr.querySelector("th p").textContent.trim() === "採用情報サイト"
  )[0];

  if (!recruitSiteTrEle) {
    // save to job
    const isSuccess = await insertJob({
      datasetId,
      tableId: jobTableId,
      row: job,
    });
    status.crawlStatus = isSuccess ? "成功" : "失敗";
    // save status, company, total_count
    await saveToDB({
      datasetId,
      statusTableId,
      status,
      companyTableId,
      company,
      totalTableId,
      totalCount,
    });
    return;
  }
  const recruitmentSiteAnchor: HTMLAnchorElement =
    recruitSiteTrEle.querySelector("td a");

  if (!recruitmentSiteAnchor) {
    // save to job
    const isSuccess = await insertJob({
      datasetId,
      tableId: jobTableId,
      row: job,
    });
    status.crawlStatus = isSuccess ? "成功" : "失敗";
    // save status, company, total_count
    await saveToDB({
      datasetId,
      statusTableId,
      status,
      companyTableId,
      company,
      totalTableId,
      totalCount,
    });

    return;
  }
  const recruitmentSiteUrl = recruitmentSiteAnchor.href;
  console.log(`採用情報サイト → ${recruitmentSiteUrl}`);

  if (companyCountInDb > 0) {
    console.log(`会社をスキップする、会社名前　→　${company.companyName}`);
    return;
  }

  const { subdomain, totalJobs, jobsPerPage, totalPages } =
    await getInfoFromRecruitSite({
      recruitmentSiteUrl,
      company,
    });

  if (subdomain === "") {
    await saveToDB({
      datasetId,
      statusTableId,
      status: null,
      companyTableId,
      company,
      totalTableId,
      totalCount,
    });
    return;
  }

  await saveToDB({
    datasetId,
    statusTableId,
    status: null,
    companyTableId,
    company: {
      ...company,
      subdomain,
    },
    totalTableId,
    totalCount: {
      subdomain,
      companyName: company.companyName,
      count: totalJobs,
      crawlerName: "tenichi",
      totalPages,
      jobsPerPage,
      insertedDate: BigQuery.date(
        moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD")
      ),
    },
  });

  // Creating tasks for each ATS job
  for (let pageNo = 1; pageNo <= totalPages; pageNo++) {
    console.log("Page No " + pageNo);
    const doc = await getDocument(
      `${recruitmentSiteUrl}search/area_1/p_${pageNo}`
    );
    const jobUrls = Array.from(doc.querySelectorAll(".goJob")).map((anchor) => {
      return (anchor as HTMLAnchorElement).href;
    });
    const filteredUrls = jobUrls.filter(
      (url) => url !== "" || url !== undefined
    );
    for (const jobUrl of filteredUrls) {
      await createTaskForJobCrawler({
        jobUrl,
        pageNo,
        subdomain,
        company,
      });
    }
  }
  return;
};
