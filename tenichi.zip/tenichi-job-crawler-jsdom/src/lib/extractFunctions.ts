export const getDataFromTable = ({
  thText,
  table,
}: {
  thText: string;
  table: HTMLTableElement;
}) => {
  if (!table) return "";
  const tr = Array.from(table.querySelectorAll("tr")).filter((tr) => {
    const th = tr.querySelector("th");
    if (!th) return false;
    return tr.querySelector("th").textContent.trim().includes(thText);
  })[0];
  return tr ? tr.querySelector("td").textContent.trim() : "";
};
export const getDataArrayFromTable = ({
  thText,
  table,
}: {
  thText: string;
  table: HTMLTableElement;
}) => {
  if (!table) return [];
  const tr = Array.from(table.querySelectorAll("tr")).filter((tr) => {
    const th = tr.querySelector("th");
    if (!th) return false;
    return tr.querySelector("th").textContent.trim().includes(thText);
  })[0];
  if (!tr) return [];
  const features = Array.from(tr.querySelectorAll("td .tokucho_icon_text")).map(
    (div) => {
      return {
        feature: div.textContent.trim().replace(/\s/g, ""),
      };
    }
  );
  return features;
};
