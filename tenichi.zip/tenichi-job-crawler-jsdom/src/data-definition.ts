import { BigQueryDatetime, BigQueryDate } from "@google-cloud/bigquery";

// JOB INFORMATION TYPES
export interface FeaturesRecord {
  feature: string;
}

// COMPANY SCHEMA
export interface Company {
  subdomain: string;
  companyName: string;
  capitalInt: number;
  capitalStr: string;
  businessContent: string;
  numberOfEmployees: number;
  headOfficeLocation: string;
  homePage: string;
  createdAt: BigQueryDate;
}

// JOB SCHEMA
export interface Job {
  jobId: number;
  subdomain: string;
  companyName: string;
  jobTitle: string;
  jobImgUrl: string;
  postUpdatedDateStr: string;
  postUpdatedDate: BigQueryDate;
  occupation: string;
  employmentStatus: string;
  salary: string;
  features: FeaturesRecord[];
  workLocation: string;
  nearestStations: string;
  workingHours: string;
  holidays: string;
  recruitmentBackground: string;
  jobDescription: string;
  benefits: string;
  appealPoints: string;
  selectionProcedure: string;
  aboutInterview: string;
  createdAt: BigQueryDatetime;
}

// STATUS SCHEMA
export interface Status {
  jobId: number;
  subdomain: string;
  companyName: string;
  url: string;
  pageNo: number;
  crawlStatus: string;
  createdAt: BigQueryDatetime;
}

// TOTAL SCHEMA
export interface TotalCount {
  subdomain: string;
  companyName: string;
  count: number;
  crawlerName: string;
  totalPages: number;
  jobsPerPage: number;
  insertedDate: BigQueryDate;
}
