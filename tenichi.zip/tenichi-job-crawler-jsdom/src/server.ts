import * as dotenv from "dotenv";
dotenv.config();
import bodyParser from "body-parser";
import express from "express";

import { crawlRecruitSiteJob } from "./lib/crawlRecruitSite";
import { crawl } from "./lib/crawl";
import moment from "moment-timezone";

// check env
import { checkEnv } from "./lib/checkEnv";

const app = express();
app.enable("trust proxy");
app.use(bodyParser.raw({ type: "application/octet-stream" }));

app.get("/", async (req, res, next) => {
  const unprovidedEnvs = checkEnv();
  if (unprovidedEnvs.length > 0) {
    return res.end();
  }

  const jobUrl = req.query.jobUrl.toString();
  const pageNo = Number(req.query.pageNo);

  await crawl({
    jobUrl,
    pageNo,
  });
  res.end();
});
app.post("/crawl-ats-job", async (req, res, next) => {
  const unprovidedEnvs = checkEnv();
  if (unprovidedEnvs.length > 0) {
    return res.end();
  }

  const body = JSON.parse(Buffer.from(req.body, "base64").toString("utf-8"));
  const jobUrl = body.jobUrl ? body.jobUrl.toString() : "";
  if (jobUrl === "") return res.end();
  const subdomain = body.subdomain.toString();
  const pageNo = Number(body.pageNo);
  const companyName = body.companyName;

  const queryDate = body.todayDate
  const date = new Date(queryDate);
  const yearMonthDay = moment(date).format("YYYYMMDD");
  // body ko twr body htl ko win

  // console.log("jobUrl is"+jobUrl);
  // console.log("subdomain is"+subdomain);
  // console.log("pageNo is"+pageNo);
  // console.log("companyName is"+companyName);
  // console.log("Date is"+yearMonthDay);
  await crawlRecruitSiteJob({
    jobUrl,
    subdomain,
    pageNo,
    companyName,
    yearMonthDay,
  });

  res.end();
});
const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log("ポート", port, "でリッスンしている");
  console.log("クローラーシステムを起動している");
});
