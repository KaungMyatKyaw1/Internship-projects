export const TOTAL_COUNT_TABLE_SCHEMA: any = {
  sourceFormat: "NEWLINE_DELIMITED_JSON",
  schema: {
    fields: [
      { name: "id", type: "STRING" },
      { name: "crawlerName", type: "STRING" },
      { name: "totalJobs", type: "INTEGER" },
      { name: "insertedDate", type: "Date" },
    ],
  },
  location: "asia-northeast1"
};