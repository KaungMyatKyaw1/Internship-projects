import * as dotenv from "dotenv";
dotenv.config();
import express from "express";
import { scheduleJobs } from "./task-scheduler";
import { checkEnv } from "./lib/checkEnv";
const app = express();

checkEnv();

app.get("/", async (req, res) => {
  const urlList = [
    "https://liner-job.net/c1/",
    "https://liner-job.net/c2/",
    "https://liner-job.net/c3/",
    "https://liner-job.net/c5/",
    "https://liner-job.net/c6/"
  ]
  await scheduleJobs(urlList)
  
  res.end();
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`Accessing: ${port}`);
});
