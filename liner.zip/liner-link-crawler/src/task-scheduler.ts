import {
  getJobLinks,
  getTotalCount
} from "./lib/element-scraper";
import { createCloudTask } from "./lib/cloud-task-for-job";
import { jobParamHelper } from "./lib/url-helper";
import { prepareTable, saveToBigQuery } from "./lib/save-to-bigquery";
import moment from "moment-timezone";
import { generateRandomStr } from "./lib/generate-random-str";
import { BigQuery } from "@google-cloud/bigquery";
import { TOTAL_COUNT_TABLE_SCHEMA } from "../schema/total-count-schema";
import { JOB_SCHEMA } from "../schema/job-schema";
import { STATUS_SCHEMA } from "../schema/status-schema";
import got from "got";
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

export const scheduleJobs = async (urlList: Array<string>) => {
  const todayDate = moment.tz(moment(), "Asia/Tokyo").format("YYYYMMDD");
  const queryDate = moment(todayDate).format("YYYY-MM-DD");
  const datasetId = process.env.DATASET_ID;
  const tableId = process.env.TOTAL_COUNT_TABLE_ID + "_" + todayDate;
  const jobTableId = process.env.JOB_TABLE_ID + "_" + todayDate;
  const statusTableId = process.env.STATUS_TABLE_ID + "_" + todayDate;

  await Promise.all([
    prepareTable({ datasetId, tableId, schema: TOTAL_COUNT_TABLE_SCHEMA }), // for total count
    prepareTable({ datasetId, tableId: jobTableId, schema: JOB_SCHEMA }), // for jobs
    prepareTable({ datasetId, tableId: statusTableId, schema: STATUS_SCHEMA }), // for status
  ]);

  const basedUrl = process.env.JOB_CRAWLER_URL;
  const queueUrl = process.env.LINER_JOB_QUEUE;
  let response: any;
  let totalAllJobs = 0;
  for (let i = 0; i < urlList.length; i++) {
    try {
      const { totalJobs, totalPages } = await getTotalCount(urlList[i]);
      totalAllJobs += totalJobs;
      for (let pageNumber = 1; pageNumber <= totalPages; pageNumber++) {
        try {
          if (pageNumber === 1) {
            response = await got(urlList[i]);
          } else if (pageNumber !== 1) {
            response = await got(urlList[i] + "page/" + pageNumber + "/");
          }
        } catch (error) {
          console.log(urlList[i] + "\nPage " + pageNumber + " has " + error);
          continue;
        }

        const htmlResponse = response.body;
        const { document } = new JSDOM(htmlResponse).window;
        const jobUrls = await getJobLinks(document);
        // console.log(jobUrls);
        // console.log(jobUrls.length);
        console.log("Extracting links from " + urlList[i] + "page/" + pageNumber);

        let pendingTasks = [];
        for (const [index, jobUrl] of jobUrls.entries()) {
          const taskUrl = jobParamHelper(basedUrl, jobUrl, pageNumber, queryDate);
          //console.log(`${taskUrl}`);
          pendingTasks.push(createCloudTask({ queueUrl, taskUrl }));
          if (pendingTasks.length > 10) {
            await Promise.all(pendingTasks);
            pendingTasks = [];
          }
        }
        await Promise.all(pendingTasks);
      }
    } catch (error) {
      console.log(urlList[i] + " has " + error);
    }
  }
  console.log("Total Jobs " + totalAllJobs);
  
  const data = {
    id: generateRandomStr(),
    crawlerName: process.env.CRAWLER_NAME,
    totalJobs: totalAllJobs,
    insertedDate: BigQuery.date(
      moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DD")
    ),
  };
  const tableRow = [data];
  await saveToBigQuery({ datasetId, tableId, tableRow }); //insert into Total_count table

};
