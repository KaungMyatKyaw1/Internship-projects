export const checkEnv = () => {
    // project
    const projectId = process.env.PROJECT_ID;
    const datasetId = process.env.DATASET_ID;
    const region = process.env.REGION;

    // queues
    const jobQueue = process.env.LINER_JOB_QUEUE

    // service acc
    const taskServiceAcc = process.env.TASK_SERVICE_ACCOUNT;

    // tables
    const statusTableId = process.env.STATUS_TABLE_ID;
    const jobsTableId = process.env.JOB_TABLE_ID;
    const totalCountTableId = process.env.TOTAL_COUNT_TABLE_ID;

    //crawler name
    const crawlerName = process.env.CRAWLER_NAME;

    const requiredEnvVariables = [
      { name: "PROJECT_ID", env: projectId },
      { name: "DATASET_ID", env: datasetId },
      { name: "REGION", env: region },
      {
        name: "LINER_JOB_QUEUE",
        env: jobQueue,
      },
      {
        name: "TASK_SERVICE_ACCOUNT",
        env: taskServiceAcc,
      },
      {
        name: "STATUS_TABLE_ID",
        env: statusTableId,
      },
      {
        name: "JOB_TABLE_ID",
        env: jobsTableId,
      },
      {
        name: "TOTAL_COUNT_TABLE_ID",
        env: totalCountTableId,
      },
      {
        name: "CRAWLER_NAME" ,
        env: crawlerName,
      }
    ];
    const unprovidedEnvs = requiredEnvVariables.filter((item) => {
      if (item.env === undefined || "") {
        console.log(`Environment variable is not provided。 -> ${item.name}`);
        return true;
      }
    });
    console.log("Unprovied envs " + unprovidedEnvs.length);
    return unprovidedEnvs;
  };