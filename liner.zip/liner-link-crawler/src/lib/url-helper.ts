export const linkParamHelper = (
  basedUrl: string,
  pageNumber: any,
  date: string,
) => {
  const searchParams = new URLSearchParams();
  const todayDate = date.toString();
  searchParams.append("pg", pageNumber);
  searchParams.append("date", todayDate)
  const taskUrl = new URL(`${basedUrl}/schedule-jobs/?${searchParams}`).toString();
  
  return taskUrl;
};

export const jobParamHelper = (
  basedUrl: string,
  jobUrl: string,
  pageNumber: any,
  todayDate: string,
) => {
  const searchParams = new URLSearchParams();

  if (!isNaN(pageNumber)) {
    const job = jobUrl ? jobUrl.toString() : "";
    const date = todayDate.toString();
    searchParams.append("url", job);
    searchParams.append("pg", pageNumber);
    searchParams.append("date", date)
  }
  const taskUrl = new URL(`${basedUrl}?${searchParams}`).toString();

  return taskUrl;
};
