import { BigQueryDatetime } from "@google-cloud/bigquery";

export interface scheduleJobsArgs {
    urlLi: string;
    document: Document;
}

export interface createCloudTaskArgs {
    queueUrl: string;
    taskUrl: string;
}

export interface DatasetArgs {
    datasetId: string;
    tableId: string;
    schema: any;
}

export interface InsertTableArgs {
    datasetId: string;
    tableId: string;
    tableRow: Row[];
}

export interface Row {
    id: string;
    crawlerName: string;
    totalJobs: number;
    insertedDate: BigQueryDatetime;
}




  