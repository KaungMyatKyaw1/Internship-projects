import { BigQuery } from "@google-cloud/bigquery";
import { TOTAL_COUNT_TABLE_SCHEMA } from "../../schema/total-count-schema";
import { DatasetArgs, InsertTableArgs } from "./data-definition";

const bigQueryClient = new BigQuery();

export const checkTable = async ({
  datasetId,
  tableId,
  schema,
}: DatasetArgs) => {
  console.log("checking table...... ");
  const result = await bigQueryClient
    .dataset(datasetId)
    .table(tableId)
    .exists();
  return result[0];
};

export const createTable = async ({
  datasetId,
  tableId,
  schema,
}: DatasetArgs) => {
  console.log("creating table....");
  return await bigQueryClient.dataset(datasetId).createTable(tableId, schema);
};

export const insertIntoTable = async ({
  datasetId,
  tableId,
  tableRow,
}: InsertTableArgs) => {
  console.log("inserting into table....");

  try {
    return await bigQueryClient
      .dataset(datasetId)
      .table(tableId)
      .insert(tableRow);
  } catch (error) {
    console.log("error while inserting into table");
    console.log(JSON.stringify(error));
  }
};
