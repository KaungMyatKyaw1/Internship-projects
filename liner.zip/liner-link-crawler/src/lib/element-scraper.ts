import got from "got";
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

export const getTotalCount = async (url: string) => {
  // console.log("getting total jobs");
  const response = await got(url);
  const htmlResponse = response.body;
  const { document } = new JSDOM(htmlResponse).window;
  const totalCountStr = document.querySelector(".icon-th-list").textContent.trim()
  const totalJobs = parseInt(totalCountStr.substring(0,totalCountStr.length-1), 10)
  const totalPages = Math.ceil(totalJobs / 30);
  return { totalJobs, totalPages };
};

export const getJobLinks = async (document: Document) => {
  const linkArr = Array.from(document.querySelectorAll(".p-list-article__buttons-detail"));
  const jobLinks = linkArr ? linkArr.map((linkArr) => linkArr.getAttribute("href")) : "";

  let values = [];
  for (const jobLink of jobLinks) {
    let urlStr = "https://liner-job.net" + jobLink;
    values.push(urlStr);
  }
  //console.log(values);
  return values;
};
const checkYear = (year: number) => {
  if (year.toString().length <= 2) {
    return Number("20" + year);
  }
  return year;
};
export const restructureDate = (arr: string[]) => {
  const year = checkYear(Number(arr[0]));
  const month = ("0" + arr[1]).slice(-2);
  const day = ("0" + arr[2]).slice(-2);

  return year + month + day;
};