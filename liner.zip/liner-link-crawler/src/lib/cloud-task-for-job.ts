import { CloudTasksClient } from "@google-cloud/tasks";
import { createCloudTaskArgs } from "./data-definition";

export const createCloudTask = async ({
  queueUrl,
  taskUrl,
}: createCloudTaskArgs) => {
  const REGION = process.env.REGION;
  const PROJECT_ID = process.env.PROJECT_ID;
  const inSeconds = 1;
  const client = new CloudTasksClient();
  const parent = client.queuePath(PROJECT_ID, REGION, queueUrl);

  console.log("Creating Task ...... ");
  const task: any = {
    httpRequest: {
      httpMethod: "GET",
      url: `${taskUrl}`,
      body: "",
      oidcToken: {
        serviceAccountEmail: process.env.TASK_SERVICE_ACCOUNT,
      },
    },
    scheduconstime: {
      seconds: inSeconds + Date.now() / 1000,
    },
  };
  try {
    const request = { parent, task };
    const [response] = await client.createTask(request);
    console.log(`${response.name} created.......................`);
  } catch (error) {
    console.log(error);
  }
};
