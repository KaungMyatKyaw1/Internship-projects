import { TOTAL_COUNT_TABLE_SCHEMA } from "../../schema/total-count-schema";
import {
  checkTable,
  createTable,
  insertIntoTable,
} from "./big-query-table";

import { DatasetArgs, InsertTableArgs } from "./data-definition";

export const prepareTable = async ({
  datasetId,
  tableId,
  schema,
}: DatasetArgs) => {
  const tableExists = await checkTable({ datasetId, tableId, schema });
  console.log(tableExists);

  if (!tableExists) {
    createTable({ datasetId, tableId, schema });
    waitSometime();
  }
};

const waitSometime = () => {
  new Promise((resolve) => setTimeout(resolve, 1000));
};

export const saveToBigQuery = async ({
  datasetId,
  tableId,
  tableRow,
}: InsertTableArgs) => {
    insertIntoTable({ datasetId, tableId, tableRow });
  console.log("Done inserting....");
};
