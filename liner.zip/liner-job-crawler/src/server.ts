import dotenv from "dotenv";
dotenv.config();
import express, { Express, Request, Response } from "express";
import moment from "moment-timezone";
import { checkEnv } from "./lib/checkEnv";
import { crawlJob } from "./lib/job-crawler-controller";

const app: Express = express();

app.get("/", async (req: Request, res: Response) => {
  checkEnv()

  console.log(
    `Get request from queue -> URL ->  ${req.query.url} , page -> ${req.query.pg}`
  );

  const queryDate = req.query.date as string | undefined;
  if(!queryDate) {
    return res.status(400).json({
      message: "date is not provided"
    })
  }
  const date = new Date(queryDate)
  const yearMonthDay = moment(date).format("YYYYMMDD");

  const url = req.query.url as string | undefined;
  if(!url) {
    return res.status(400).json({
      message: "url is not specified"
    })
  }
  const queryPage = req.query.pg ? req.query.pg.toString() : "0"

  const page = parseInt(queryPage, 10)
  if(isNaN(page)) {
    return res.status(400).json({
      message: "invalid page"
    })
  }

  await crawlJob({ url, page, yearMonthDay });
  res.status(200).end();
});

const port = process.env.PORT || 8080;

app.listen(port, () => {
  console.log(`MyNavi Crawler app is listening`);
});
