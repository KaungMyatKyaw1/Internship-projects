import { BigQuery } from "@google-cloud/bigquery";
import { InsertIntoTableArgs } from "./data-definitions";

const bigQueryClient = new BigQuery();

export const insertIntoTable = async ({
  datasetId,
  tableId,
  schema,
  tableRow,
}: InsertIntoTableArgs) => {
  console.log("inserting into table....");
  try {
    return await bigQueryClient
      .dataset(datasetId)
      .table(tableId, schema)
      .insert(tableRow);
  } catch (error) {
    console.log("error while inserting into table");
    console.log("error br nyr" + JSON.stringify(error));
  }
};
