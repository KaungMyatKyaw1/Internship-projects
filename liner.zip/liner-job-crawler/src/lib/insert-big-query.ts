import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment-timezone";
import { JOB_SCHEMA } from "../../schema/job-schema";
import { STATUS_SCHEMA } from "../../schema/status-schema";
import { insertIntoTable } from "./big-query-table-helper";
import { JobArgs } from "./data-definitions";

interface bigQueryArgs {
  job: JobArgs;
  page: number;
  yearMonthDay: string;
}
export const insertIntoBigQuery = async ({
  job,
  page,
  yearMonthDay,
}: bigQueryArgs) => {
  const date = yearMonthDay;
  console.log("this is the yearMonth day in insertIntoBigQuery" + date);

  const datasetId = process.env.DATASET_ID;
  const jobTableId = process.env.JOB_TABLE_ID + "_" + date;
  const statusTableId = process.env.STATUS_TABLE_ID + "_" + date;

    try {
      // INSERT INTO JOB TABLE
      await insertIntoTable({
        datasetId,
        tableId: jobTableId,
        schema: JOB_SCHEMA,
        tableRow: job,
      });
      // INSERTING INTO STATUS TABLE WITH SUCCESS
      await insertIntoTable({
        datasetId,
        tableId: statusTableId,
        schema: STATUS_SCHEMA,
        tableRow: {
          jobId: job.jobId,
          pageNumber: page,
          url : job.pageURL,
          crawlStatus: "成功", // success
          createdAt: BigQuery.date(
            moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
          ),
        },
      });
      return;
    } catch (error) {
      console.log(
        "Error while inserting job info line: \n" + JSON.stringify(error)
      );
      // INSERTING INTO STATUS TABLE WITH FAIL
      await insertIntoTable({
        datasetId,
        tableId: statusTableId,
        schema: STATUS_SCHEMA,
        tableRow: {
          jobId: job.jobId,
          pageNumber: page,
          url : job.pageURL,
          crawlStatus: "失敗", // failed
          createdAt: BigQuery.date(
            moment.tz(moment(), "Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
          ),
        },
      });
      return;
    }
};
