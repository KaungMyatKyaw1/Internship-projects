export const checkEnv = () => {
    // project
    const projectId = process.env.PROJECT_ID;
    const datasetId = process.env.DATASET_ID;

    // tables
    const statusTableId = process.env.STATUS_TABLE_ID;
    const jobsTableId = process.env.JOB_TABLE_ID;

    const requiredEnvVariables = [
      { name: "PROJECT_ID", env: projectId },
      { name: "DATASET_ID", env: datasetId },
      {
        name: "STATUS_TABLE_ID",
        env: statusTableId,
      },
      {
        name: "JOB_TABLE_ID",
        env: jobsTableId,
      },
    ];
    const unprovidedEnvs = requiredEnvVariables.filter((item) => {
      if (item.env === undefined || "") {
        console.log(`Environment variable is not provided。 -> ${item.name}`);
        return true;
      }
    });
    console.log("Unprovied envs " + unprovidedEnvs.length);
    return unprovidedEnvs;
  };