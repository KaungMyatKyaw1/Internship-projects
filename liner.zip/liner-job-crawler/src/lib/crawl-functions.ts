import {
  GetJobData,
  GetJobRecordData,
} from "./data-definitions";

export const getInfo = async ({ selector, document }: GetJobData) => {
  const element = document.querySelector(selector)
  const value = element? element.textContent.replace(/(\r\n|\n|\r|\t|\s)/gm, "") : "";
  return value;
};
export const getElementByTitle = async ({
  selector,
  document,
  text,
}: GetJobRecordData) => {
  let element: Element;

  element = Array.from(document.querySelectorAll(selector)).find(
    (el) => el.textContent.trim() == text
  );

  return element;
};
export const getTags = async ({ selector, document }: GetJobData) => {
  const tags = Array.from(document.querySelectorAll(selector)).map((el) => {
    return {
      tag: el.textContent.trim(),
    };
  });
  return tags;
};
export const getDataFromTable = async ({
  selector,
  document,
  text,
}: GetJobRecordData) => {
  const th = await getElementByTitle({ selector, document, text });
  if (!th) return "";
  const td = th.nextElementSibling.textContent
    .trim()
    .replace(/(\r\n|\n|\r|\t|\s)/gm, "");
  return td;
};
