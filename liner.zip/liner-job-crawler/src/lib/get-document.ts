import got from "got";
const jsdom = require("jsdom");
const { JSDOM } = jsdom;

export const getDocument = async (url: string) => {
  try {
    const response = await got(url);
    const htmlResponse = response.body;
    const { document } = new JSDOM(htmlResponse).window;
    return document;
  } catch (error) {
    console.log(error);
    return false;
  }
};
