import { BigQueryDatetime } from "@google-cloud/bigquery";

export interface JobArgs{
  pageURL : string;
  jobId : string;

  //intro
  jobTitle : string;
  occupation : string;
  employmentStatus: string;
  companyURL : string;

  //recruitment information table
  jobDescription : string;
  requirements : string;
  workingHours : string;
  holidays : string;
  salary : string;
  benefits : string;
  training : string;
  applicationMethod : string;
  other : string;
  activity : string;
  interview : string;
  jobTags : TagArgs[];

  //company data
  companyName : string;
  established : string;
  representative : string;
  capital : string;
  numberOfEmployees : string;
  businessContent : string;
  workLocation : string;
  
  crawledDate: BigQueryDatetime;
}
export interface InsertIntoTableArgs {
  datasetId: string;
  tableId: string;
  schema: any;
  tableRow: any;
}
export interface CrawlJobArgs {
  url: string;
  page: number;
  yearMonthDay: string;
}
export interface GetJobData {
  selector: string;
  document: Document;
}
export interface GetJobRecordData extends GetJobData{
  text: string;
}
export interface TagArgs {
  tag: string;
}