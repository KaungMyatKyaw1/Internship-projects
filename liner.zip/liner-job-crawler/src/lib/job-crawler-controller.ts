import dotenv from "dotenv";
import { insertIntoBigQuery } from "./insert-big-query";
import { CrawlJobArgs } from "./data-definitions";
import { crawlRecruitmentInfo } from "./crawl-recruitment-info";
import { getDocument } from "./get-document";

dotenv.config();

export const crawlJob = async ({ url, page, yearMonthDay }: CrawlJobArgs) => {

  try {
    
    const document: any = await getDocument(url);
    // 403
    if(document == false){
      return;
    }
    // crawl job info
    const job = await crawlRecruitmentInfo(
      url,
      document
    );
    //console.log(job);

    await insertIntoBigQuery({ job, page, yearMonthDay });
    console.timeEnd("Insert Time Taken");

  } catch (error) {
    console.log(`Error JobID :  ${url}`);
    console.log(error);
  }
};
