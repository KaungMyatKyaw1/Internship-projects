import { BigQuery } from "@google-cloud/bigquery";
import moment from "moment";
import { getDataFromTable, getInfo, getTags } from "./crawl-functions";
import { JobArgs } from "./data-definitions";
export const crawlRecruitmentInfo = async (url: string, document: Document) => {
  console.log("URL is " + url);

  const pageURL = url;
  const jobId = pageURL.split("https://")[1].split("/")[1];

  const jobTitle = await getInfo({
    selector: ".p-typo__t-wrapper-title",
    document,
  });

  const employmentStatus = await getInfo({
    selector: ".job .c-categoryicon",
    document,
  });

  //jobstr = occupation + employmentStatus
  const jobstr = await getInfo({
    selector: ".job",
    document,
  });
  const occupation = jobstr.replace(employmentStatus, "");

  const companyURL = await getInfo({
    selector: ".url",
    document,
  });

  const jobDescription = await getDataFromTable({
    selector: "th",
    text: "内容",
    document,
  });

  const requirements = await getDataFromTable({
    selector: "th",
    text: "資格",
    document,
  });

  const workingHours = await getDataFromTable({
    selector: "th",
    text: "勤務",
    document,
  });

  const holidays = await getDataFromTable({
    selector: "th",
    text: "休日",
    document,
  });

  const salary = await getDataFromTable({
    selector: "th",
    text: "給与",
    document,
  });

  const benefits = await getDataFromTable({
    selector: "th",
    text: "待遇",
    document,
  });

  const training = await getDataFromTable({
    selector: "th",
    text: "研修",
    document,
  });

  const applicationMethod = await getDataFromTable({
    selector: "th",
    text: "応募",
    document,
  });

  const other = await getDataFromTable({
    selector: "th",
    text: "その他・PR",
    document,
  });

  const activity = await getDataFromTable({
    selector: "th",
    text: "活動",
    document,
  });

  const interview = await getDataFromTable({
    selector: "th",
    text: "面接",
    document,
  });

  const jobTags = await getTags({
    selector: ".p-label-merit__label",
    document,
  });

  const companyName = await getDataFromTable({
    selector: "th",
    text: "企業名",
    document,
  });

  const established = await getDataFromTable({
    selector: "th",
    text: "設立",
    document,
  });

  const representative = await getDataFromTable({
    selector: "th",
    text: "代表者",
    document,
  });

  const capital = await getDataFromTable({
    selector: "th",
    text: "資本金",
    document,
  });

  const numberOfEmployees = await getDataFromTable({
    selector: "th",
    text: "従業員数",
    document,
  });

  const businessContent = await getDataFromTable({
    selector: "th",
    text: "事業内容",
    document,
  });

  const workLocation = await getDataFromTable({
    selector: "th",
    text: "所在地",
    document,
  });

  const job: JobArgs = {
    pageURL,
    jobId,

    //intro
    jobTitle,
    occupation,
    employmentStatus,
    companyURL,

    //recruitment information table
    jobDescription,
    requirements,
    workingHours,
    holidays,
    salary,
    benefits,
    training,
    applicationMethod,
    other,
    activity,
    interview,
    jobTags,

    //company data
    companyName,
    established,
    representative,
    capital,
    numberOfEmployees,
    businessContent,
    workLocation,

    crawledDate: BigQuery.datetime(
      moment(new Date()).tz("Asia/Tokyo").format("YYYY-MM-DDTHH:mm:ss")
    ),
  };
  return job;
};
