export const STATUS_SCHEMA: any = {
    sourceFormat: "NEWLINE_DELIMITED_JSON",
    schema: {
      fields: [
        { name: "jobId", type: "STRING" },
        { name: "pageNumber", type: "STRING" },
        { name: "url", type: "STRING" },
        { name: "crawlStatus", type: "STRING" },
        {
          name: "createdAt",
          type: "DATETIME",
        },
      ],
    },
    location: "asia-northeast1",
  };