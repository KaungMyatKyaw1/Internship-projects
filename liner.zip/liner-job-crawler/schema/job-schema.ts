export const JOB_SCHEMA: any = {
  sourceFormat: "NEWLINE_DELIMITED_JSON",
  schema: {
    fields: [
      { name: "pageURL", type: "STRING" },
      { name: "jobId", type: "STRING" },

      //default link
      //intro
      { name: "jobTitle", type: "STRING" },
      { name: "occupation", type: "STRING" },
      { name: "employmentStatus", type: "STRING" },
      { name: "companyURL", type: "STRING" },

      //recruitment information table
      { name: "jobDescription", type: "STRING" },
      { name: "requirements", type: "STRING" },
      { name: "workingHours", type: "STRING" },
      { name: "holidays", type: "STRING" },
      { name: "salary", type: "STRING" },
      { name: "benefits", type: "STRING" },
      { name: "training", type: "STRING" },
      { name: "applicationMethod", type: "STRING" },
      { name: "other", type: "STRING" },
      { name: "activity", type: "STRING" },
      { name: "interview", type: "STRING" },
      { 
        name: "jobTags", 
        type: "RECORD", 
        mode: "REPEATED",
        fields: [
          {
            name: "tag",
            type: "STRING",
          }
        ],
      },

      //company data
      { name: "companyName", type: "STRING" },
      { name: "established", type: "STRING" },
      { name: "representative", type: "STRING" },
      { name: "capital", type: "STRING" },
      { name: "numberOfEmployees", type: "STRING" },
      { name: "businessContent", type: "STRING" },
      { name: "workLocation", type: "STRING" },

      { name: "crawledDate", type: "DATETIME" },
    ],
  },
  location: "asia-northeast1",
};